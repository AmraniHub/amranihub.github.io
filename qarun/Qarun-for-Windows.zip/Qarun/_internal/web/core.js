"use strict";
// Qarun on the laptop: state, the link with the local server, and the store rules ported from the phone (Store.kt).
// Every change is made on R (the data); commit() sends what changed to the server, which stamps it and shares it
// with the linked phone. The server's answer (and any change from the phone, via watch()) replaces R.

let S = null;                 // the server's last state: {ver, seq, root, pairs, pairing, name, ip, data}
let R = {};                   // the data (same shape as the phone)
let snap = new Map();
let snapRun = "null";
let pending = 0;
const UI = loadUi({ view: "today", tview: "today", task: null, txEdit: null, planEdit: null, month: "", folder: null, calMonth: "", calDay: "",
  tlDay: "", query: "", sel: [], modal: null, showGoals: false, showEntries: false, showAccounts: true, planDays: 30, histShown: 40, entShown: 60 });
const A = {}, ENTER = {}, CHANGE = {}, VIEW = {};
let ctr = 0;
const $ = (q, el = document) => el.querySelector(q);

function loadUi(d) { try { const o = JSON.parse(localStorage.getItem("qd_ui") || "{}"); for (const k of ["view", "tview", "task", "folder"]) if (o[k] !== undefined) d[k] = o[k]; } catch (e) { } return d; }
function keepUi() { try { localStorage.setItem("qd_ui", JSON.stringify({ view: UI.view, tview: UI.tview, task: UI.task, folder: UI.folder })); } catch (e) { } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function api(path, body) {
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json", "X-Qarun-UI": "1" }, body: JSON.stringify(body) };
  const r = await fetch(path, opt);
  if (!r.ok) throw new Error("HTTP " + r.status);
  return r.json();
}

/** The same record keys as the phone. All settings come through here (the server shares only the shared ones). */
function records(root) {
  const out = {};
  for (const [c, v] of Object.entries(root)) {
    if (c.startsWith("_") || ["v", "run", "app", "exported"].includes(c)) continue;
    if (Array.isArray(v)) { for (const o of v) if (o && o.id) out[c + "/" + o.id] = o; }
    else if (v && typeof v === "object") {
      if (c === "hdone") { for (const [h, days] of Object.entries(v)) for (const [d, x] of Object.entries(days || {})) out["hdone/" + h + "/" + d] = x; }
      else for (const [k, x] of Object.entries(v)) out[c + "/" + k] = x;
    }
  }
  return out;
}

let BUILD = null;
function adopt(st) {
  if (BUILD === null) BUILD = st.build; else if (st.build && st.build !== BUILD) { location.reload(); return; }
  S = st; R = st.root || {};
  snap = new Map(Object.entries(records(R)).map(([k, v]) => [k, JSON.stringify(v)]));
  snapRun = JSON.stringify(R.run || null);
  render();
}

/** Call after every change to R. */
async function commit() {
  const cur = records(R); const ops = [];
  for (const [k, v] of Object.entries(cur)) { if (snap.get(k) !== JSON.stringify(v)) ops.push({ k, v }); }
  for (const k of snap.keys()) if (!(k in cur)) ops.push({ k, del: true });
  const run = JSON.stringify(R.run || null);
  if (run !== snapRun) ops.push({ k: "run", v: R.run || null });
  render();
  if (!ops.length) return;
  pending++;
  try { const st = await api("/ui/ops", { ops }); pending--; adopt(st); }
  catch (e) { pending--; toast("Not saved: the Qarun server is not running"); }
}

async function watch() {
  for (;;) {
    try {
      const st = await api("/ui/state?ver=" + (S ? S.ver : -1));
      if (BUILD && st.build && st.build !== BUILD && !UI.modal) { location.reload(); return; }
      if (!pending && (!S || st.ver !== S.ver)) adopt(st);
      else if (!pending && S) { S.pairs = st.pairs; S.pairing = st.pairing; }
    } catch (e) { S && setSide(false); await sleep(2500); }
  }
}

function toast(t) {
  const el = $("#toast"); el.textContent = t; el.style.display = "block";
  clearTimeout(toast.t); toast.t = setTimeout(() => (el.style.display = "none"), 1800 + 40 * t.length);
}

// ===================================================================== dates, numbers
const pad = (n) => String(n).padStart(2, "0");
const ymd = (d) => d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
const parseD = (s) => { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d); };
const today = () => ymd(new Date());
const addDays = (s, n) => { const d = parseD(s); d.setDate(d.getDate() + n); return ymd(d); };
const addMonths = (s, n) => { const d = parseD(s); const day = d.getDate(); d.setDate(1); d.setMonth(d.getMonth() + n); d.setDate(Math.min(day, new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate())); return ymd(d); };
const monthLen = (ym) => { const [y, m] = ym.split("-").map(Number); return new Date(y, m, 0).getDate(); };
const monday = (s = today()) => { const d = parseD(s); const w = (d.getDay() + 6) % 7; d.setDate(d.getDate() - w); return ymd(d); };
const nowHM = () => { const d = new Date(); return pad(d.getHours()) + ":" + pad(d.getMinutes()); };
const hmMin = (s) => { const m = /^(\d\d?):(\d\d)$/.exec(s || ""); return m ? +m[1] * 60 + +m[2] : null; };
const hhmm = (m) => pad(Math.floor(m / 60) % 24) + ":" + pad(m % 60);
const endTime = (at, min) => { const m = hmMin(at); return m == null ? "" : hhmm(m + (min || 0)); };
const newId = () => Date.now().toString(36) + "L" + (ctr++);
const h = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const num = (v) => { const x = parseFloat(String(v == null ? "" : v).replace(/\s/g, "").replace(",", ".")); return isFinite(x) ? x : 0; };
function fmtMoney(a) {
  a = +a || 0;
  if (Number.isInteger(a)) return a.toLocaleString("en-US");
  return a.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 8 });
}
function fmtMin(m) { m = Math.round(m); if (m <= 0) return "0 min"; if (m < 60) return m + " min"; if (m % 60 === 0) return m / 60 + " h"; return Math.floor(m / 60) + " h " + (m % 60) + " min"; }
function dayLabel(d) {
  if (!d) return "";
  const t = today();
  if (d === t) return "Today"; if (d === addDays(t, 1)) return "Tomorrow"; if (d === addDays(t, -1)) return "Yesterday";
  return parseD(d).toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" });
}
const monthName = (ym) => parseD(ym + "-01").toLocaleDateString("en-GB", { month: "long", year: "numeric" });
const DOW = ["M", "T", "W", "T", "F", "S", "S"];
const dow1 = (d) => DOW[(parseD(d).getDay() + 6) % 7];
function ago(ms) {
  if (!ms) return "never"; const s = Math.round((Date.now() - ms) / 1000);
  if (s < 5) return "just now"; if (s < 60) return s + " s ago"; if (s < 3600) return Math.round(s / 60) + " min ago";
  if (s < 86400) return Math.round(s / 3600) + " h ago"; return Math.round(s / 86400) + " days ago";
}

// ===================================================================== look (same as the phone)
const LIST_COLORS = ["#D4AF37", "#6FA8FF", "#5FD39A", "#FFB547", "#FF6B6B", "#B892FF", "#4FD1C5", "#FF8FB1", "#A09A8C"];
const listColorOf = (i) => LIST_COLORS[i] || LIST_COLORS[0];
const PRIO_COLORS = ["#A09A8C", "#6FA8FF", "#FFB547", "#FF6B6B"];
const PRIO_NAMES = ["None", "Low", "Medium", "High"];
const REPEATS = [["", "Never"], ["daily", "Daily"], ["weekdays", "Weekdays"], ["weekly", "Weekly"], ["monthly", "Monthly"], ["yearly", "Yearly"]];
const REMINDS = [[0, "On time"], [5, "5 min before"], [15, "15 min before"], [30, "30 min before"], [60, "1 hour before"], [1440, "1 day before"]];
const repeatName = (r) => (REPEATS.find((x) => x[0] === r) || [0, "Never"])[1];
const LIST_ICONS = ["📥", "💼", "🏠", "💰", "📈", "🏢", "🤝", "📞", "✉️", "🧾", "🏋️", "🥗", "❤️", "🧠", "📚", "🎓", "🗣️", "✈️", "🛒", "🚗",
  "👨‍👩‍👧", "🕌", "🎯", "🚀", "💡", "🛠️", "🎨", "🎵", "📸", "🌿", "⭐", "🔥", "⚡", "🏆", "📅", "📝", "🧳", "🏖️", "💎", "🦁"];
const ACT_ICONS = ["🧠", "💻", "📚", "🇺🇸", "🇪🇸", "🇫🇷", "🗣️", "✍️", "🎓", "📖", "🏋️", "🏃", "🚴", "🏊", "🧘", "⚽", "🥊", "🕌", "📿", "🎨",
  "🎵", "🎸", "📸", "🎬", "💼", "📞", "📈", "💰", "🛠️", "🧹", "🍳", "🌿", "🚗", "✈️", "👨‍👩‍👧", "❤️", "🎯", "🚀", "⏱", "☕"];
const HABIT_ICONS = ["💧", "🏋️", "🏃", "🧘", "📖", "🕌", "📿", "🤲", "🥗", "🍎", "😴", "🛌", "🦷", "🧴", "💊", "🚭", "📵", "☀️", "🌙", "🚶",
  "✍️", "🗣️", "🇺🇸", "🧠", "💰", "📞", "🧹", "🌿", "❤️", "✨"];
const STARTER_FOLDERS = [["💡", "Business ideas"], ["🚀", "Projects for later"], ["📚", "To learn"], ["✈️", "Someday"], ["🛒", "To buy one day"], ["🎁", "Gift ideas"]];
const FIAT = [["MAD", "🇲🇦"], ["USD", "🇺🇸"], ["EUR", "🇪🇺"], ["GBP", "🇬🇧"], ["AED", "🇦🇪"], ["SAR", "🇸🇦"], ["QAR", "🇶🇦"], ["KWD", "🇰🇼"], ["BHD", "🇧🇭"], ["OMR", "🇴🇲"],
  ["JOD", "🇯🇴"], ["EGP", "🇪🇬"], ["TND", "🇹🇳"], ["DZD", "🇩🇿"], ["MRU", "🇲🇷"], ["XOF", "🌍"], ["XAF", "🌍"], ["NGN", "🇳🇬"], ["ZAR", "🇿🇦"], ["TRY", "🇹🇷"],
  ["CHF", "🇨🇭"], ["CAD", "🇨🇦"], ["AUD", "🇦🇺"], ["NZD", "🇳🇿"], ["JPY", "🇯🇵"], ["CNY", "🇨🇳"], ["HKD", "🇭🇰"], ["SGD", "🇸🇬"], ["KRW", "🇰🇷"], ["INR", "🇮🇳"],
  ["PKR", "🇵🇰"], ["IDR", "🇮🇩"], ["MYR", "🇲🇾"], ["THB", "🇹🇭"], ["PHP", "🇵🇭"], ["RUB", "🇷🇺"], ["SEK", "🇸🇪"], ["NOK", "🇳🇴"], ["DKK", "🇩🇰"], ["PLN", "🇵🇱"],
  ["CZK", "🇨🇿"], ["HUF", "🇭🇺"], ["RON", "🇷🇴"], ["ILS", "🇮🇱"], ["BRL", "🇧🇷"], ["MXN", "🇲🇽"], ["ARS", "🇦🇷"], ["XAU", "🥇"], ["XAG", "🥈"]];
const CRYPTO = [["BTC", "₿"], ["ETH", "Ξ"], ["USDT", "₮"], ["USDC", "$"], ["BNB", "◆"], ["SOL", "◎"], ["XRP", "✕"], ["TON", "◈"], ["TRX", "▲"], ["DOGE", "Ð"],
  ["ADA", "₳"], ["LTC", "Ł"], ["DOT", "●"], ["AVAX", "▲"], ["POL", "⬡"], ["LINK", "⬢"], ["XLM", "✦"], ["ATOM", "⚛"], ["SUI", "💧"], ["NOT", "N"],
  ["SHIB", "🐕"], ["PEPE", "🐸"], ["DAI", "◈"], ["BCH", "Ƀ"]];
const curSign = (c) => ((FIAT.concat(CRYPTO)).find((x) => x[0] === c) || [c, "¤"])[1];

// ===================================================================== the store (ported from Store.kt)
const arr = (n) => (Array.isArray(R[n]) ? R[n] : (R[n] = []));
const obj = (n) => (R[n] && typeof R[n] === "object" && !Array.isArray(R[n]) ? R[n] : (R[n] = {}));
const find = (n, id) => arr(n).find((o) => o.id === id);
const removeId = (n, id) => { R[n] = arr(n).filter((o) => o.id !== id); };
const setting = (k, d = "") => { const v = obj("set")[k]; return v === undefined || v === null || v === "" ? d : v; };
const setSetting = (k, v) => { obj("set")[k] = v; };
const creed = () => setting("creed", "Time and money: spend both like an investor.");

// ---- lists
const lists = () => arr("lists");
const taskLists = () => lists().filter((l) => !l.idea);
const ideaFolders = () => lists().filter((l) => l.idea);
const isIdeaFolder = (id) => !!(find("lists", id) || {}).idea;
const listName = (id) => (find("lists", id) || {}).name || "Inbox";
const listIcon = (id) => (find("lists", id) || {}).icon || ({ inbox: "📥", work: "💼", personal: "🏠" }[id] || "📁");
const listColor = (id) => listColorOf((find("lists", id) || {}).color || 0);
function addList(name, icon = "", color = 0, idea = false) { const id = newId(); lists().push({ id, name: name.trim(), icon, color, idea }); return id; }
function deleteList(id) { if (id === "inbox") return; tasks().filter((t) => t.list === id).forEach((t) => (t.list = "inbox")); removeId("lists", id); }

// ---- tasks
const tasks = () => arr("tasks");
const isDone = (t) => !!t.done;
const subs = (t) => (Array.isArray(t.sub) ? t.sub : (t.sub = []));
const order = (a, b) => (b.prio || 0) - (a.prio || 0) || (a.time || "99").localeCompare(b.time || "99") || (a.created || 0) - (b.created || 0);
const todayTasks = () => { const t = today(); return tasks().filter((x) => !isDone(x) && x.due && x.due <= t).sort((a, b) => (a.due >= t) - (b.due >= t) || order(a, b)); };
const upcoming = () => { const t = today(); return tasks().filter((x) => !isDone(x) && x.due > t).sort((a, b) => a.due.localeCompare(b.due) || order(a, b)); };
const inList = (id) => tasks().filter((x) => !isDone(x) && x.list === id).sort((a, b) => (a.due || "9999").localeCompare(b.due || "9999") || order(a, b));
const ideasIn = (id) => tasks().filter((x) => !isDone(x) && x.list === id).sort((a, b) => (!!a.due - !!b.due) || (b.created || 0) - (a.created || 0));
const doneTasks = () => tasks().filter(isDone).sort((a, b) => (b.done || "").localeCompare(a.done || "") || (b.created || 0) - (a.created || 0));
const lateTasks = () => tasks().filter((x) => !isDone(x) && x.due && x.due < today());
const tasksOn = (d) => tasks().filter((x) => (!isDone(x) && x.due === d) || x.done === d).sort((a, b) => isDone(a) - isDone(b) || order(a, b));
const doneOn = (d) => obj("doneLog")[d] || 0;
const nextSub = (t) => subs(t).find((x) => !x.done);

function addTask(title, list, due, extra) {
  const t = Object.assign({ id: newId(), title: title.trim(), note: "", list: list || "inbox", due: due || "", time: "", prio: 0, repeat: "", created: Date.now(), done: "", sub: [] }, extra || {});
  tasks().push(t); return t;
}
function toggleTask(id) {
  const t = find("tasks", id); if (!t) return false;
  const td = today();
  if (isDone(t)) { if (t.hist) removeId("tasks", id); else t.done = ""; return false; }
  const log = obj("doneLog");
  if (t.repeat) {
    const due = t.due || td;
    const base = due < td ? td : due;
    let next;
    if (t.repeat === "daily") next = addDays(base, 1);
    else if (t.repeat === "weekly") next = addDays(base, 7);
    else if (t.repeat === "weekdays") { next = addDays(base, 1); while ([0, 6].includes(parseD(next).getDay())) next = addDays(next, 1); }
    else if (t.repeat === "yearly") next = addMonths(base, 12);
    else next = addMonths(base, 1);
    t.due = next;
    subs(t).forEach((s) => (s.done = false));
    tasks().push({ id: newId(), title: t.title, note: t.note || "", list: t.list, due, time: t.time || "", prio: t.prio || 0, repeat: "", created: Date.now(), done: td, hist: true });
    log[td] = (log[td] || 0) + 1;
    return true;
  }
  t.done = td; log[td] = (log[td] || 0) + 1;
  return true;
}
/** A tick from anywhere: stops the focus timer that was on it, says so. */
function finishTask(id) {
  const t = find("tasks", id); if (!t) return;
  const now = toggleTask(id);
  if (now) {
    const r = running();
    if (r && r.task === id) { const m = stopTimer(); if (m >= 1) toast("+" + fmtMin(m) + " saved"); }
    toast(t.repeat ? "Done. Next one is planned" : "Done ✓");
  }
}
function clearHistory(before) {
  const gone = new Set(tasks().filter((t) => isDone(t) && (!before || t.done < before)).map((t) => t.id));
  R.tasks = tasks().filter((t) => !gone.has(t.id)); return gone.size;
}
function subToTask(taskId, subId) {
  const t = find("tasks", taskId); const s = t && subs(t).find((x) => x.id === subId); if (!s) return;
  t.sub = subs(t).filter((x) => x.id !== subId);
  addTask(s.t, t.list, t.due, { prio: t.prio || 0 });
}
function nextUp() {
  const nm = hmMin(nowHM()); const td = today();
  const open = todayTasks(); const todays = open.filter((t) => t.due === td);
  const st = (t) => hmMin(t.time);
  let x = todays.find((t) => st(t) != null && nm >= st(t) - 15 && nm < st(t) + Math.max(t.dur || 30, 30)); if (x) return x;
  x = todays.filter((t) => st(t) != null && st(t) > nm && st(t) - nm <= 120).sort((a, b) => st(a) - st(b))[0]; if (x) return x;
  x = open.filter((t) => t.due < td).sort((a, b) => (b.prio || 0) - (a.prio || 0))[0]; if (x) return x;
  const later = todays.filter((t) => st(t) == null || st(t) >= nm).sort((a, b) => (b.prio || 0) - (a.prio || 0) || (st(b) ?? 9999) - (st(a) ?? 9999));
  return later[0] || todays[0] || null;
}
const prioColor = (t) => (!(t.prio > 0) ? "var(--gold)" : PRIO_COLORS[Math.min(3, t.prio)]);

// ---- activities and time
const acts = () => arr("acts");
const act = (id) => find("acts", id);
const actName = (id) => (act(id) || {}).name || "Deleted";
const actIcon = (id) => (act(id) || {}).icon || ({ "Deep work": "🧠", English: "🇺🇸", Spanish: "🇪🇸", Gym: "🏋️" }[(act(id) || {}).name] || "⏱");
const actColor = (id) => listColorOf((act(id) || {}).color || 0);
const actSubs = (id) => { const a = act(id); return a ? (Array.isArray(a.sub) ? a.sub : (a.sub = [])) : []; };
const sessions = () => arr("sessions");
const minutes = (a, from, to) => sessions().filter((s) => (a == null || s.act === a) && s.d >= from && s.d <= to).reduce((n, s) => n + (s.min || 0), 0);
const minutesToday = (a = null) => minutes(a, today(), today());
const minutesWeek = (a = null) => minutes(a, monday(), today());
const daysLeftInWeek = () => 8 - (((parseD(today()).getDay() + 6) % 7) + 1);
function todayTarget(a) {
  const goal = (act(a) || {}).goal || 0; if (goal <= 0) return 0;
  const td = today(); const before = td === monday() ? 0 : minutes(a, monday(), addDays(td, -1));
  return Math.ceil(Math.max(0, goal - before) / daysLeftInWeek());
}
const tasksForAct = (id) => tasks().filter((t) => !isDone(t) && t.act === id).sort((a, b) => (a.due || "9999").localeCompare(b.due || "9999") || (b.prio || 0) - (a.prio || 0));
const nextForAct = (id) => { const t = tasksForAct(id)[0]; if (t) return t.title; const s = actSubs(id).find((x) => !x.done); return s ? s.t : null; };
const minutesOnTask = (id) => sessions().filter((s) => s.task === id).reduce((n, s) => n + (s.min || 0), 0);
const listAct = (listId) => { const a = setting("la_" + listId); return a && act(a) ? a : ""; };
const actForTask = (t) => (t.act && act(t.act) ? t.act : "") || listAct(t.list) ||
  (acts().find((a) => /work|travail/i.test(a.name)) || acts()[0] || {}).id || "";
function saveAct(id, v) {
  const a = id && act(id);
  if (a) { Object.assign(a, v); return a.id; }
  const nid = newId(); acts().push(Object.assign({ id: nid, name: "", goal: 0, icon: "", color: 0 }, v)); return nid;
}
function deleteAct(id) { removeId("acts", id); R.sessions = sessions().filter((s) => s.act !== id); if (running() && running().act === id) delete R.run; }
function clearSessions(before) { const n = sessions().length; R.sessions = sessions().filter((s) => s.d >= before); return n - R.sessions.length; }
const running = () => R.run || null;
const elapsed = (r = running()) => (r ? (r.acc || 0) + (r.paused ? 0 : Date.now() - (r.start || Date.now())) : 0);
function startTimer(a, focus = 0, task = "") {
  stopTimer();
  const now = Date.now();
  R.run = { act: a, start: now, begun: now, acc: 0, paused: false, focus, task };
  if (a) setSetting("lastAct", a);
}
function pauseTimer() { const r = running(); if (!r || r.paused) return; r.acc = elapsed(r); r.paused = true; }
function resumeTimer() { const r = running(); if (!r || !r.paused) return; r.start = Date.now(); r.paused = false; }
function stopTimer(keepMin = -1) {
  const r = running(); if (!r) return 0;
  delete R.run;
  const min = keepMin >= 0 ? keepMin : Math.floor(elapsed(r) / 60000);
  const b = new Date(r.begun || r.start);
  const text = r.task ? ((find("tasks", r.task) || {}).title || "") : "";
  if (min >= 1) sessions().push({ id: newId(), act: r.act, d: today(), min, note: text, at: pad(b.getHours()) + ":" + pad(b.getMinutes()), task: r.task || "" });
  return min;
}
/** A time entry: a new one on any day; an existing one only while its day is today (past days are locked). */
function saveSession(id, v) {
  const s = id && find("sessions", id);
  if (s && s.d < today()) return false;
  if (s) Object.assign(s, v); else sessions().push(Object.assign({ id: newId() }, v));
  return true;
}

// ---- habits
const habits = () => arr("habits");
const hdays = (id) => { const m = obj("hdone"); return m[id] || (m[id] = {}); };
const habitDone = (id, d = today()) => !!(obj("hdone")[id] || {})[d];
function toggleHabitOn(id, d) { const m = hdays(id); if (m[d]) delete m[d]; else m[d] = 1; }
function habitStreak(id) { let d = habitDone(id) ? today() : addDays(today(), -1); let n = 0; while (habitDone(id, d)) { n++; d = addDays(d, -1); } return n; }
function habitBest(id) {
  const days = Object.keys((obj("hdone")[id]) || {}).sort(); let best = 0, cur = 0, prev = null;
  for (const d of days) { cur = prev && d === addDays(prev, 1) ? cur + 1 : 1; best = Math.max(best, cur); prev = d; }
  return best;
}
const habitRate = (id, n = 30) => { let c = 0; for (let i = 0; i < n; i++) if (habitDone(id, addDays(today(), -i))) c++; return c; };
function deleteHabit(id) { removeId("habits", id); delete obj("hdone")[id]; }

// ---- money
const accounts = () => arr("accounts");
const curOf = (acc) => (find("accounts", acc) || {}).cur || "MAD";
const accName = (acc) => (find("accounts", acc) || {}).name || "";
const txs = () => arr("tx");
const cats = (kind) => arr("cats").filter((c) => c.kind === kind);
const catName = (id) => (find("cats", id) || {}).name || "Other";
function catIcon(id) {
  const c = find("cats", id); if (c && c.icon) return c.icon;
  const n = ((c && c.name) || "").toLowerCase();
  const pairs = [["food", "🍽️"], ["restaurant", "🍽️"], ["coffee", "☕"], ["cafe", "☕"], ["home", "🏠"], ["bill", "🏠"], ["rent", "🏠"], ["transport", "🚗"], ["car", "🚗"], ["fuel", "🚗"], ["taxi", "🚗"],
    ["family", "👨‍👩‍👧"], ["business", "💼"], ["work", "💼"], ["health", "💊"], ["pharm", "💊"], ["cloth", "👕"], ["fun", "🎉"], ["leisure", "🎉"], ["phone", "📱"], ["internet", "📱"], ["client", "🤝"],
    ["salary", "💵"], ["gift", "🎁"], ["invest", "📈"]];
  for (const [k, e] of pairs) if (n.includes(k)) return e;
  return c && c.kind === "in" ? "💰" : "🧾";
}
function balance(acc) {
  let b = 0;
  for (const t of txs()) {
    const a = +t.amt || 0;
    if (t.type === "in" && t.acc === acc) b += a;
    else if (t.type === "out" && t.acc === acc) b -= a;
    else if (t.type === "move" && t.acc === acc) b -= a;
    else if (t.type === "move" && t.to === acc) b += t.toAmt != null ? +t.toAmt : a;
  }
  return b;
}
const accountUsed = (id) => txs().some((t) => t.acc === id || t.to === id);
function saveAccount(id, name, cur) {
  const a = id && find("accounts", id);
  if (a) { a.name = name.trim(); a.cur = cur.trim().toUpperCase(); } else accounts().push({ id: newId(), name: name.trim(), cur: cur.trim().toUpperCase() });
}
function deleteAccount(id) { if (accountUsed(id) || accounts().length <= 1) return false; removeId("accounts", id); return true; }
function saveCat(id, name, kind, budget) {
  const c = id && find("cats", id);
  if (c) { c.name = name.trim(); c.budget = budget; } else arr("cats").push({ id: newId(), name: name.trim(), kind, budget });
}
const monthTx = (m) => txs().filter((t) => (t.d || "").startsWith(m)).sort((a, b) => (b.d || "").localeCompare(a.d || "") || (b.id || "").localeCompare(a.id || ""));
function totals(list) {
  const out = {};
  for (const t of list) { const c = curOf(t.acc); const o = out[c] || (out[c] = [0, 0]); if (t.type === "in") o[0] += +t.amt || 0; if (t.type === "out") o[1] += +t.amt || 0; }
  return out;
}
function spendByCat(m) {
  const out = {};
  for (const t of monthTx(m).filter((x) => x.type === "out")) { const k = t.cat + "|" + curOf(t.acc); out[k] = (out[k] || 0) + (+t.amt || 0); }
  return Object.entries(out).map(([k, v]) => [k.split("|")[0], k.split("|")[1], v]).sort((a, b) => b[2] - a[2]);
}
function dayFlow(ym, cur) {
  const out = [];
  for (let d = 1; d <= monthLen(ym); d++) {
    const k = ym + "-" + pad(d); const day = txs().filter((t) => t.d === k && curOf(t.acc) === cur);
    out.push([day.filter((t) => t.type === "in").reduce((n, t) => n + (+t.amt || 0), 0), day.filter((t) => t.type === "out").reduce((n, t) => n + (+t.amt || 0), 0)]);
  }
  return out;
}
function mainCur() {
  const n = {}; for (const t of txs()) { const c = curOf(t.acc); n[c] = (n[c] || 0) + 1; }
  const best = Object.entries(n).sort((a, b) => b[1] - a[1])[0];
  return best ? best[0] : (accounts()[0] || {}).cur || "MAD";
}
function holdings() { const o = {}; for (const a of accounts()) o[a.cur] = (o[a.cur] || 0) + balance(a.id); return o; }
function recentTx(n = 6) {
  const seen = new Set(); const out = [];
  for (const t of txs().filter((x) => x.type !== "move").sort((a, b) => (b.d || "").localeCompare(a.d || "") || (b.id || "").localeCompare(a.id || ""))) {
    const k = t.type + t.cat + (+t.amt) + t.acc; if (!seen.has(k)) { seen.add(k); out.push(t); } if (out.length >= n) break;
  }
  return out;
}
const repeatTx = (t) => txs().push({ id: newId(), type: t.type, acc: t.acc, amt: +t.amt, cat: t.cat, note: t.note || "", d: today() });

// ---- savings goals
const goals = () => arr("goals");
function saveGoal(id, name, cur, target) {
  const g = id && find("goals", id);
  if (g) Object.assign(g, { name: name.trim(), cur: cur.trim().toUpperCase(), target }); else goals().push({ id: newId(), name: name.trim(), cur: cur.trim().toUpperCase(), target, saved: 0 });
}
function moveGoal(id, delta) { const g = find("goals", id); if (g) g.saved = (+g.saved || 0) + delta; }

// ---- the money plan
const plans = () => arr("plans");
const openPlans = (kind) => plans().filter((p) => !p.done && (!kind || p.kind === kind)).sort((a, b) => (a.date || "9999").localeCompare(b.date || "9999"));
const planLeft = (p) => (p.kind === "debt" ? Math.max(0, (+p.amt || 0) - (+p.paid || 0)) : +p.amt || 0);
const planSign = (p) => (p.kind === "in" ? 1 : p.kind === "debt" ? (p.owe === false ? 1 : -1) : -1);
const plansForTask = (id) => openPlans().filter((p) => p.task === id);
function accFor(cur) {
  const last = setting("lastAcc");
  if (last && find("accounts", last) && curOf(last) === cur) return last;
  return ((accounts().find((a) => a.cur === cur) || accounts()[0]) || {}).id || "";
}
const catFor = (p, kind) => (cats(kind).some((c) => c.id === p.cat) ? p.cat : (cats(kind)[0] || {}).id || "");
function completePlan(id, amount = -1) {
  const p = find("plans", id); if (!p) return;
  const a = amount > 0 ? amount : planLeft(p);
  const cur = p.cur || mainCur();
  const type = planSign(p) > 0 ? "in" : "out";
  if (a > 0) txs().push({ id: newId(), type, acc: accFor(cur), amt: a, cat: catFor(p, type), note: p.title || "", d: today() });
  if (p.kind === "bill") {
    const d = p.date || today(); const rep = p.repeat ?? "monthly";
    if (rep === "") p.done = today(); else p.date = rep === "weekly" ? addDays(d, 7) : rep === "yearly" ? addMonths(d, 12) : addMonths(d, 1);
  } else if (p.kind === "debt") { p.paid = (+p.paid || 0) + a; if (planLeft(p) <= 0.009) p.done = today(); }
  else p.done = today();
}
function planFlow(days, cur) {
  const until = addDays(today(), days); let inn = 0, out = 0;
  for (const p of openPlans().filter((p) => (p.cur || mainCur()) === cur && p.date && p.date <= until)) { if (planSign(p) > 0) inn += planLeft(p); else out += planLeft(p); }
  return [inn, out];
}
function debtTotals(cur) {
  const d = openPlans("debt").filter((p) => (p.cur || mainCur()) === cur);
  return [d.filter((p) => p.owe !== false).reduce((n, p) => n + planLeft(p), 0), d.filter((p) => p.owe === false).reduce((n, p) => n + planLeft(p), 0)];
}
const PLAN_KINDS = { in: ["💵", "Expected income", "var(--green)"], bill: ["🧾", "Bill", "var(--amber)"], out: ["🛒", "Planned spending", "var(--gold)"], debt: ["🤝", "Debt", "var(--red)"] };
const planIcon = (p) => (p.kind === "debt" ? (p.owe !== false ? "🔻" : "🔺") : (PLAN_KINDS[p.kind] || PLAN_KINDS.out)[0]);
const planAction = (p) => ({ in: "✓ Received", out: "✓ Bought", bill: "✓ Paid" }[p.kind] || (p.owe !== false ? "Pay…" : "Got…"));

// ---- wealth
function dayNet(d, cur) {
  let n = 0;
  for (const t of txs().filter((x) => x.d === d)) {
    const inCur = curOf(t.acc) === cur;
    if (t.type === "in" && inCur) n += +t.amt || 0;
    else if (t.type === "out" && inCur) n -= +t.amt || 0;
    else if (t.type === "move") { if (inCur) n -= +t.amt || 0; if (curOf(t.to) === cur) n += t.toAmt != null ? +t.toAmt : +t.amt || 0; }
  }
  return n;
}
function netWorth(cur) { const [owe, owed] = debtTotals(cur); return (holdings()[cur] || 0) + owed - owe; }
function holdingHistory(cur, days = 30) {
  let v = holdings()[cur] || 0; const out = [];
  for (let i = 0; i < days; i++) { out.push(v); v -= dayNet(addDays(today(), -i), cur); }
  return out.reverse();
}
