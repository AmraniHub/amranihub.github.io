"use strict";
// Money: what you hold, accounts, a new entry, one-tap repeats, the money plan, the month, where it went,
// savings goals and the entries.

VIEW.money = () => {
  const hold = holdings(); const mc = mainCur();
  const m = UI.month || today().slice(0, 7);
  const hs = Object.entries(hold).sort((a, b) => (a[0] === mc ? -1 : b[0] === mc ? 1 : 0));
  const recent = recentTx();
  let s = `<h1>Money</h1><div class="money-tiles">${hs.map(([c, v], i) => `<div class="${i ? "v2" : "v"} ${v < 0 ? "red" : ""}">${curSign(c)} ${fmtMoney(v)} ${c}</div>`).join("")}</div>
  <div class="grid cols2"><div>${entryForm()}
   ${recent.length ? `<div class="kicker" style="margin-top:14px">AGAIN, ONE CLICK</div><div>${recent.map((x) => { const inc = x.type === "in"; return pill(catIcon(x.cat) + " " + (inc ? "+" : "−") + fmtMoney(x.amt) + " " + h(catName(x.cat)), false, `data-a="repeatTx" data-id="${x.id}" title="${h(accName(x.acc))}${x.note ? " · " + h(x.note) : ""}"`); }).join("")}</div>` : ""}
   ${accountsCard()}${planSection()}${goalsCard()}
  </div><div>${monthCard(m)}${whereItWent(m)}
   <div class="kicker" style="margin-top:16px">🧾 Entries · ${monthTx(m).length}</div><div class="card">
     <div class="row click" data-a="toggleEntries"><span>🧾</span><div class="grow gold">${UI.showEntries ? "Hide entries ▴" : monthTx(m).length + " entries this month ▾"}</div></div>
     ${UI.showEntries ? txRows(monthTx(m)) : ""}</div>
  </div></div>`;
  return s;
};

function entryForm() {
  const e = UI.txEdit || { type: "out", d: today(), acc: setting("lastAcc") && find("accounts", setting("lastAcc")) ? setting("lastAcc") : (accounts()[0] || {}).id };
  const kc = cats(e.type === "in" ? "in" : "out");
  const cat = e.cat && kc.some((c) => c.id === e.cat) ? e.cat : mostUsedCat(e.type, kc);
  return `<div class="kicker">${e.id ? "✏ Change entry" : "➕ New entry"}</div><div class="card pad form">
    <div>${[["out", "− Expense"], ["in", "+ Income"], ["move", "⇄ Transfer"]].map(([v, n]) => pill(n, e.type === v, `data-a="txType" data-v="${v}"`, v === "in" ? "var(--green)" : v === "move" ? "var(--blue)" : null)).join("")}</div>
    <div class="line"><input type="text" id="x_amt" class="big" style="flex:1" placeholder="0" value="${e.amt != null ? h(e.amt) : ""}" data-enter="saveTx" autocomplete="off">
      <select id="x_acc">${accounts().map((a) => opt(a.id, e.acc, a.name + " · " + a.cur)).join("")}</select></div>
    ${e.type === "move" ? `<div class="line"><label>To</label><select id="x_to">${accounts().map((a) => opt(a.id, e.to || (accounts().find((x) => x.id !== e.acc) || {}).id, a.name + " · " + a.cur)).join("")}</select>
      <input type="text" id="x_toAmt" placeholder="amount that arrived (other currency)" value="${e.toAmt != null ? h(e.toAmt) : ""}" style="flex:1"></div>
      ${accounts().length < 2 ? '<div class="amber small">Add a second account first (Accounts, + Account).</div>' : ""}` :
      `<div class="catgrid">${kc.map((c) => `<button class="catb ${cat === c.id ? "on" : ""}" data-a="txCat" data-id="${c.id}"><span>${catIcon(c.id)}</span>${h(c.name)}</button>`).join("")}</div>`}
    <div class="line"><label>When</label><input type="date" id="x_d" value="${h(e.d || today())}"><button class="ghost" data-a="txDay" data-d="0">Today</button><button class="ghost" data-a="txDay" data-d="-1">Yesterday</button></div>
    <input type="text" id="x_note" placeholder="${e.type === "in" ? "From who (optional)" : "Note (optional)"}" value="${h(e.note || "")}" data-enter="saveTx">
    <div id="x_why" class="red small"></div>
    <div class="btns"><button class="btn" data-a="saveTx">${e.id ? "Save changes" : "Save"}</button>${e.id ? '<button class="ghost" data-a="txCancel">Cancel</button><button class="ghost red" data-a="delTx" data-id="' + e.id + '">Delete</button>' : ""}</div></div>`;
}
function mostUsedCat(type, kc) {
  const n = {}; txs().filter((t) => t.type === type).forEach((t) => (n[t.cat] = (n[t.cat] || 0) + 1));
  const best = Object.entries(n).sort((a, b) => b[1] - a[1]).find(([k]) => kc.some((c) => c.id === k));
  return best ? best[0] : (kc[0] || {}).id || "";
}

function accountsCard() {
  return `<div class="kicker" style="margin-top:16px">🏦 Accounts <button class="x" data-a="toggleAccounts">${UI.showAccounts ? "▴" : "▾"}</button></div><div class="card">
    ${UI.showAccounts ? accounts().map((a) => `<div class="row click" data-a="accEdit" data-id="${a.id}" title="Click to edit"><span>${curSign(a.cur)}</span><div class="grow t">${h(a.name)}</div><b class="${balance(a.id) < 0 ? "red" : ""}">${fmtMoney(balance(a.id))} ${a.cur}</b><span class="muted small">✎</span></div>`).join("") : ""}
    <div class="row click" data-a="accNew"><span class="gold">＋</span><div class="grow gold">Account (cash, bank, Wise…)</div></div></div>`;
}

function monthCard(m) {
  const mc = mainCur(); const tot = totals(monthTx(m)); const [inM, outM] = tot[mc] || [0, 0]; const td = today(); const isNow = m === td.slice(0, 7);
  const days = isNow ? +td.slice(8) : monthLen(m);
  const flow = dayFlow(m, mc); const top = Math.max(1, ...flow.map(([a, b]) => Math.max(a, b)));
  const budget = cats("out").reduce((n, c) => n + (+c.budget || 0), 0);
  let bud = "";
  if (budget > 0 && isNow) { const left = budget - outM; const dl = monthLen(m) - +td.slice(8) + 1; bud = `<div class="small ${left >= 0 ? "gold2" : "red"}">${left >= 0 ? `Budget left: ${fmtMoney(left)} ${mc} · ${fmtMoney(Math.round(left / dl))} a day until the end of the month` : `Over budget by ${fmtMoney(-left)} ${mc}`}</div>`; }
  return `<div class="line" style="display:flex;align-items:center;gap:8px;margin-bottom:8px"><button class="ghost" data-a="month" data-by="-1">‹</button>
     <h2 style="margin:0;flex:1;text-align:center">${monthName(m)}</h2><button class="ghost" data-a="month" data-by="1" ${m >= td.slice(0, 7) ? "disabled" : ""}>›</button></div>
   <div class="card pad"><div class="kicker" style="margin:0">KEPT THIS MONTH</div>
     <div class="${inM - outM >= 0 ? "green" : "red"}" style="font:bold 30px var(--serif)">${inM - outM >= 0 ? "+" : "−"}${fmtMoney(Math.abs(inM - outM))} ${mc}</div>
     <div class="stats3 left"><div><span>IN</span><b class="green">+${fmtMoney(inM)}</b></div><div><span>OUT</span><b>−${fmtMoney(outM)}</b></div><div><span>SPENT A DAY</span><b>${fmtMoney(Math.round(outM / Math.max(1, days)))}</b></div></div>
     <div class="mchart">${flow.map(([a, b], i) => `<div class="${isNow && i + 1 === +td.slice(8) ? "td" : ""}" title="${i + 1}: +${fmtMoney(a)} / −${fmtMoney(b)}"><i class="in" style="height:${(a / top) * 50}px"></i><i class="out" style="height:${(b / top) * 50}px"></i></div>`).join("")}</div>
     ${bud}${Object.entries(tot).filter(([c]) => c !== mc).map(([c, [i, o]]) => `<div class="small muted">${c}: in ${fmtMoney(i)}, out ${fmtMoney(o)}</div>`).join("")}</div>`;
}

function whereItWent(m) {
  const mc = mainCur(); const sc = spendByCat(m); const outAll = Math.max(1, sc.filter((x) => x[1] === mc).reduce((n, x) => n + x[2], 0));
  const budgets = cats("out").filter((c) => +c.budget > 0);
  return `<div class="kicker" style="margin-top:16px">🧭 Where it went</div><div class="card">${sc.length ? "" : '<div class="empty">No spending this month.</div>'}
    ${sc.map(([cat, c, amt]) => { const b = +(find("cats", cat) || {}).budget || 0; const over = b > 0 && amt > b;
      return `<div class="row"><span class="bigicon sm">${catIcon(cat)}</span><div class="grow"><div class="line" style="display:flex"><span style="flex:1">${h(catName(cat))}</span><b class="${over ? "red" : ""}">${fmtMoney(amt)} ${c}${b > 0 ? " / " + fmtMoney(b) : ""}</b></div>
        ${bar(b > 0 ? amt / b : amt / outAll, over ? "var(--red)" : null)}${c === mc && b <= 0 ? `<div class="meta">${Math.round((amt * 100) / outAll)}% of your spending</div>` : ""}</div></div>`; }).join("")}
    ${budgets.filter((b) => !sc.some((x) => x[0] === b.id)).map((b) => `<div class="row"><span class="bigicon sm">${catIcon(b.id)}</span><div class="grow">${h(b.name)}</div><span class="meta">0 / ${fmtMoney(b.budget)}</span></div>`).join("")}
    <div class="row click" data-a="catsOpen"><span>🏷</span><div class="grow gold">Categories and monthly budgets</div></div></div>`;
}

function goalsCard() {
  const gs = goals(); const mc = mainCur(); const saved = gs.filter((g) => g.cur === mc).reduce((n, g) => n + (+g.saved || 0), 0);
  return `<div class="kicker" style="margin-top:16px">🎯 Savings goals</div><div class="card">
    ${gs.length ? `<div class="row click" data-a="toggleGoals"><span>🎯</span><div class="grow gold">${UI.showGoals ? "Hide goals ▴" : gs.length + " goals ▾"}</div>${UI.showGoals ? "" : `<b class="gold">${fmtMoney(saved)} ${mc}</b>`}</div>` :
      '<div class="empty">A goal is money you keep apart: a war chest, a car, a house, your children\'s future.</div>'}
    ${UI.showGoals || !gs.length ? gs.map((g) => { const sv = +g.saved || 0, tg = +g.target || 0;
      return `<div class="row" style="display:block"><div class="line click" style="display:flex" data-a="goalEdit" data-id="${g.id}"><b style="flex:1">${h(g.name)}</b><b class="gold">${fmtMoney(sv)}${tg > 0 ? " / " + fmtMoney(tg) : ""} ${h(g.cur)}</b></div>
        ${tg > 0 ? bar(sv / tg, sv >= tg ? "var(--green)" : null) : ""}
        <div class="line" style="display:flex;align-items:center;gap:6px;margin-top:6px"><span class="small muted" style="flex:1">${tg <= 0 ? "" : sv >= tg ? "✓ Reached" : Math.floor((sv * 100) / tg) + "% · " + fmtMoney(tg - sv) + " to go"}</span>
        <button class="ghost gold small" data-a="goalMove" data-id="${g.id}" data-sign="1">+ Put in</button><button class="ghost small" data-a="goalMove" data-id="${g.id}" data-sign="-1">−</button></div></div>`; }).join("") +
      '<div class="row click" data-a="goalNew"><span class="gold">➕</span><div class="grow gold">New savings goal</div></div>' : ""}</div>`;
}

function txRows(list) {
  let s = "", last = ""; const mc = mainCur();
  for (const x of list.slice(0, UI.entShown)) {
    if (x.d !== last) {
      const net = list.filter((y) => y.d === x.d && curOf(y.acc) === mc).reduce((n, y) => n + (y.type === "in" ? +y.amt : y.type === "out" ? -y.amt : 0), 0);
      s += `<div class="row" style="padding:8px 14px 2px"><b class="gold small" style="flex:1">${dayLabel(x.d)}</b><span class="meta">${net >= 0 ? "+" : "−"}${fmtMoney(Math.abs(net))} ${mc}</span></div>`; last = x.d;
    }
    const inc = x.type === "in", mv = x.type === "move";
    s += `<div class="row click ${UI.txEdit && UI.txEdit.id === x.id ? "sel" : ""}" data-a="editTx" data-id="${x.id}"><span>${mv ? "⇄" : catIcon(x.cat)}</span>
      <div class="grow"><div class="t">${mv ? h(accName(x.acc)) + " → " + h(accName(x.to)) : h(catName(x.cat))}</div><div class="meta">${[h(accName(x.acc)), h(x.note || "")].filter(Boolean).join(" · ")}</div></div>
      <b class="${inc ? "green" : ""}">${inc ? "+" : mv ? "" : "−"}${fmtMoney(x.amt)} ${curOf(x.acc)}</b></div>`;
  }
  if (list.length > UI.entShown) s += '<div class="row"><button class="ghost" data-a="entMore">Show more</button></div>';
  return s || '<div class="empty">Click − Expense or + Income to log money.</div>';
}

// ---------------------------------------------------------------- the money plan
function planSection() {
  const mc = mainCur(); const days = UI.planDays || 30; const [inn, out] = planFlow(days, mc); const hold = holdings()[mc] || 0; const end = hold + inn - out;
  const [owe, owed] = debtTotals(mc); const p = UI.planEdit;
  let s = `<div class="kicker" style="margin-top:16px">🗓 Money plan</div><div class="card pad sec">
    <div>${[7, 30, 90].map((d) => pill(d + " days", days === d, `data-a="planDays" data-v="${d}"`)).join("")}</div>
    <div class="kicker" style="margin:6px 0 0">IF EVERYTHING GOES AS PLANNED</div><div class="${end >= 0 ? "gold2" : "red"}" style="font:bold 26px var(--serif)">${fmtMoney(end)} ${mc}</div>
    <div class="small muted">Now ${fmtMoney(hold)} ${mc} · coming in +${fmtMoney(inn)} · going out −${fmtMoney(out)}</div>
    ${end < 0 ? `<div class="small red">Short by ${fmtMoney(-end)} ${mc}. Chase the income, or move a purchase later.</div>` : ""}
    ${owe > 0 || owed > 0 ? `<div class="small muted">Debts: you owe ${fmtMoney(owe)} ${mc} · owed to you ${fmtMoney(owed)} ${mc}</div>` : ""}</div>`;
  for (const [kind, title, icon] of [["in", "Expected income", "💵"], ["bill", "Bills", "🧾"], ["out", "Planned spending", "🛒"], ["debt", "Debts", "🤝"]]) {
    const items = openPlans(kind); const tot = items.filter((x) => (x.cur || mc) === mc).reduce((n, x) => n + planLeft(x) * planSign(x), 0);
    s += `<div class="kicker">${icon} ${title}${items.length ? " · " + (tot >= 0 ? "+" : "−") + fmtMoney(Math.abs(tot)) + " " + mc : ""}</div><div class="card sec">
      ${items.map((x) => planRow(x)).join("")}
      ${p && !p.id && p.kind === kind ? planForm(p) : `<div class="row click" data-a="planNew" data-kind="${kind}"><span class="gold">➕</span><div class="grow gold">${{ in: "Add expected income", bill: "Add a bill", out: "Add planned spending", debt: "Add a debt" }[kind]}</div></div>`}</div>`;
  }
  return s + `<div class="muted small">When it happens, click the button on its line: Qarun writes the real entry in Money. A bill moves to its next date.</div>`;
}
function planRow(x) {
  if (UI.planEdit && UI.planEdit.id === x.id) return planForm(UI.planEdit);
  const late = x.date && x.date < today(); const sign = planSign(x) > 0; const tk = x.task && find("tasks", x.task);
  const bits = [x.date ? (late ? "late: " : "") + dayLabel(x.date) : "", x.kind === "bill" && x.repeat ? "🔁 " + repeatName(x.repeat) : "", h(x.who || ""),
    x.kind === "debt" && +x.paid > 0 ? fmtMoney(x.paid) + " of " + fmtMoney(x.amt) + " paid" : "", tk ? "☑ " + h(tk.title) : ""].filter(Boolean);
  return `<div class="row click" data-a="planEdit" data-id="${x.id}"><span class="bigicon sm">${planIcon(x)}</span><div class="grow"><div class="t">${h(x.title)}</div>${bits.length ? `<div class="meta ${late ? "red" : ""}">${bits.join("  ·  ")}</div>` : ""}</div>
    <b class="${sign ? "green" : ""}">${sign ? "+" : "−"}${fmtMoney(planLeft(x))} ${x.cur || mainCur()}</b>
    <button class="ghost gold small" data-a="planAct" data-id="${x.id}">${planAction(x)}</button></div>`;
}
function planForm(p) {
  const curs = Array.from(new Set(accounts().map((a) => a.cur).concat([p.cur || mainCur()])));
  const catKind = p.kind === "in" || (p.kind === "debt" && p.owe === false) ? "in" : "out";
  return `<div class="form" style="padding:12px 14px;border-top:1px solid var(--line)">
    <div>${Object.entries(PLAN_KINDS).map(([v, k]) => pill(k[0] + " " + k[1], p.kind === v, `data-a="planKind" data-v="${v}"`)).join("")}</div>
    ${p.kind === "debt" ? `<div>${pill("I owe", p.owe !== false, 'data-a="planOwe" data-v="1"', "var(--red)")}${pill("Owed to me", p.owe === false, 'data-a="planOwe" data-v="0"', "var(--blue)")}</div>` : ""}
    <input type="text" id="p_title" placeholder="${{ in: "e.g. Hamid: website payment", bill: "e.g. Internet, rent, phone", out: "e.g. New laptop" }[p.kind] || "e.g. Loan from Simo"}" value="${h(p.title || "")}" autofocus>
    <div class="line"><input type="text" id="p_amt" class="big" placeholder="0" style="width:170px" value="${p.amt != null ? h(p.amt) : ""}" data-enter="planSave">
      <select id="p_cur">${curs.map((c) => opt(c, p.cur || mainCur(), curSign(c) + " " + c)).join("")}</select>
      <label style="min-width:auto">${p.kind === "bill" ? "Next due" : p.kind === "in" ? "Expected on" : "When"}</label><input type="date" id="p_date" value="${h(p.date || "")}">
      ${p.kind === "bill" ? `<select id="p_rep">${[["monthly", "Monthly"], ["weekly", "Weekly"], ["yearly", "Yearly"], ["", "Once"]].map(([v, n]) => opt(v, p.repeat ?? "monthly", n)).join("")}</select>` : ""}</div>
    ${p.kind === "debt" && +p.paid > 0 ? `<div class="small muted">${fmtMoney(p.paid)} of ${fmtMoney(p.amt)} paid</div>` : ""}
    <input type="text" id="p_who" placeholder="${p.kind === "in" ? "From who" : p.kind === "debt" ? "With who" : "Where / to who"} (optional)" value="${h(p.who || "")}">
    <div class="line"><label>Category</label><select id="p_cat">${opt("", p.cat || "", "—")}${cats(catKind).map((c) => opt(c.id, p.cat || "", catIcon(c.id) + " " + c.name)).join("")}</select>
      <label style="min-width:auto">Task</label><select id="p_task">${opt("", p.task || "", "—")}${tasks().filter((t) => !isDone(t) || t.id === p.task).sort((a, b) => (a.due || "9999").localeCompare(b.due || "9999")).slice(0, 80).map((t) => opt(t.id, p.task || "", t.title)).join("")}</select></div>
    <div id="p_why" class="red small"></div>
    <div class="btns"><button class="btn" data-a="planSave">Save</button><button class="ghost" data-a="planCancel">Cancel</button>
      ${!p.task && (p.title || "").trim() ? '<button class="ghost gold" data-a="planMakeTask">✨ Create a task for it</button>' : ""}
      ${p.id ? '<button class="ghost red" data-a="planDel" data-id="' + p.id + '">Delete</button>' : ""}</div></div>`;
}

// ---------------------------------------------------------------- dialogs
MODAL.acc = (m) => {
  const d = m.d; const isNew = !m.id;
  return dlg(isNew ? "New account" : "Edit account", `<input type="text" data-m="name" value="${h(d.name)}" placeholder="Name (Cash, CIH bank, Wise…)" style="width:100%" autofocus data-enter="accSave">
    <div class="line" style="margin-top:10px"><label>Currency</label><select data-m="cur">${curOptions(d.cur)}</select></div>
    ${isNew ? '<div class="small muted">To start with the money already in it, save, then add an Income with the amount.</div>' : `<div class="small muted">Balance ${fmtMoney(balance(m.id))} ${h(curOf(m.id))}</div>`}`,
    `${isNew ? "" : '<button class="ghost red" data-a="accDel">Delete</button>'}<span style="flex:1"></span><button class="ghost" data-a="closeModal">Cancel</button><button class="btn" data-a="accSave">Save</button>`);
};
MODAL.goal = (m) => {
  const d = m.d; const isNew = !m.id;
  return dlg(isNew ? "New goal" : "Edit goal", `<input type="text" data-m="name" value="${h(d.name)}" placeholder="Name (War chest, Car, House…)" style="width:100%" autofocus>
    <div class="line" style="margin-top:10px"><label>Currency</label><select data-m="cur">${curOptions(d.cur)}</select></div>
    <div class="line"><label>Target</label><input type="text" data-m="target" value="${h(d.target || "")}" placeholder="optional" data-enter="goalSave"></div>`,
    `${isNew ? "" : '<button class="ghost red" data-a="goalDel">Delete</button>'}<span style="flex:1"></span><button class="ghost" data-a="closeModal">Cancel</button><button class="btn" data-a="goalSave">Save</button>`);
};
MODAL.cats = (m) => {
  const e = m.edit;
  if (e) return dlg(e.id ? "Edit category" : "New category", `<input type="text" data-m="name" value="${h(m.d.name || "")}" placeholder="Name" style="width:100%" autofocus data-enter="catSave">
      ${e.kind === "out" ? `<div class="line" style="margin-top:10px"><label>Monthly budget</label><input type="text" data-m="budget" value="${h(m.d.budget || "")}" placeholder="optional" data-enter="catSave"></div>` : ""}`,
    `${e.id && cats(e.kind).length > 1 ? '<button class="ghost red" data-a="catDel">Delete</button>' : ""}<span style="flex:1"></span><button class="ghost" data-a="catBack">Back</button><button class="btn" data-a="catSave">Save</button>`);
  return dlg("Categories", ["out", "in"].map((kind) => `<div class="kicker" style="margin-top:10px">${kind === "out" ? "Expenses (with optional monthly budget)" : "Income"}</div><div class="card">
      ${cats(kind).map((c) => `<div class="row click" data-a="catEdit" data-id="${c.id}"><span>${catIcon(c.id)}</span><div class="grow">${h(c.name)}</div>${+c.budget > 0 ? `<span class="meta">budget ${fmtMoney(c.budget)}</span>` : ""}</div>`).join("")}
      <div class="row click" data-a="catNew" data-kind="${kind}"><span class="gold">＋</span><div class="grow gold">Category</div></div></div>`).join(""),
    `<button class="btn" data-a="closeModal">Close</button>`);
};

// ---------------------------------------------------------------- actions
function readTx() {
  const e = Object.assign({}, UI.txEdit || {});
  const v = (id) => ($(id) ? $(id).value : undefined);
  e.type = e.type || "out"; e.amt = v("#x_amt"); e.acc = v("#x_acc"); e.d = v("#x_d"); e.note = v("#x_note");
  if ($("#x_to")) e.to = v("#x_to"); if ($("#x_toAmt")) e.toAmt = v("#x_toAmt");
  if (!e.cat || !cats(e.type === "in" ? "in" : "out").some((c) => c.id === e.cat)) e.cat = mostUsedCat(e.type, cats(e.type === "in" ? "in" : "out"));
  return e;
}
function readPlan() {
  const p = Object.assign({}, UI.planEdit || {});
  const v = (id) => ($(id) ? $(id).value : undefined);
  p.title = v("#p_title"); p.amt = v("#p_amt"); p.cur = v("#p_cur"); p.date = v("#p_date"); p.who = v("#p_who");
  if ($("#p_rep")) p.repeat = v("#p_rep"); if ($("#p_cat")) p.cat = v("#p_cat"); if ($("#p_task")) p.task = v("#p_task");
  return p;
}
Object.assign(A, {
  txType(el) { UI.txEdit = Object.assign(readTx(), { type: el.dataset.v, cat: "" }); render(); },
  txCat(el) { UI.txEdit = Object.assign(readTx(), { cat: el.dataset.id }); render(); },
  txDay(el) { UI.txEdit = Object.assign(readTx(), { d: addDays(today(), +el.dataset.d) }); render(); },
  editTx(el) { const x = find("tx", el.dataset.id); if (x) { UI.txEdit = JSON.parse(JSON.stringify(x)); render(); const i = $("#x_amt"); if (i) { i.focus(); i.scrollIntoView({ block: "center" }); } } },
  txCancel() { UI.txEdit = null; render(); },
  async delTx(el) { if (!await ask("Delete this entry? It goes from the phone too.")) return; removeId("tx", el.dataset.id); UI.txEdit = null; toast("Entry deleted"); commit(); },
  saveTx() {
    const e = readTx(); const why = $("#x_why");
    const a = num(e.amt);
    if (!(a > 0)) { why.textContent = "Type the amount first"; $("#x_amt").focus(); return; }
    const x = { type: e.type, acc: e.acc, amt: a, note: (e.note || "").trim(), d: e.d || today() };
    if (e.type === "move") {
      if (!e.to || e.to === e.acc) { why.textContent = accounts().length < 2 ? "Add a second account first (Accounts, + Account)." : "Pick the account it goes to"; return; }
      const same = curOf(e.acc) === curOf(e.to); const ta = num(e.toAmt);
      if (!same && !(ta > 0)) { why.textContent = "Type the amount that arrived"; return; }
      x.to = e.to; x.toAmt = same ? a : ta;
    } else x.cat = e.cat || "";
    if (e.id) { const old = find("tx", e.id); if (old) { for (const k of ["type", "acc", "to", "amt", "toAmt", "cat", "note", "d"]) { if (k in x) old[k] = x[k]; else delete old[k]; } } }
    else txs().push(Object.assign({ id: newId() }, x));
    setSetting("lastAcc", e.acc);
    toast((x.type === "in" ? "+" : x.type === "out" ? "−" : "⇄ ") + fmtMoney(a) + " " + curOf(e.acc) + (x.cat ? "  ·  " + catName(x.cat) : ""));
    UI.txEdit = { type: e.type, d: today(), acc: e.acc };
    commit();
  },
  repeatTx(el) { const x = find("tx", el.dataset.id); if (!x) return; repeatTx(x); toast("Logged " + (x.type === "in" ? "+" : "−") + fmtMoney(x.amt) + " " + curOf(x.acc) + ": " + catName(x.cat)); commit(); },
  month(el) { const m = UI.month || today().slice(0, 7); UI.month = addMonths(m + "-01", +el.dataset.by).slice(0, 7); UI.entShown = 60; render(); },
  toggleEntries() { UI.showEntries = !UI.showEntries; render(); },
  toggleGoals() { UI.showGoals = !UI.showGoals; render(); },
  toggleAccounts() { UI.showAccounts = !UI.showAccounts; render(); },
  entMore() { UI.entShown += 60; render(); },
  accNew() { openModal("acc", { d: { name: "", cur: mainCur() } }); },
  accEdit(el) { const a = find("accounts", el.dataset.id); if (a) openModal("acc", { id: a.id, d: { name: a.name, cur: a.cur } }); },
  accSave() { const m = UI.modal; const name = (m.d.name || "").trim(); if (!name || (m.d.cur || "").length < 3) { toast("Give the account a name"); return; } saveAccount(m.id, name, m.d.cur); UI.modal = null; commit(); },
  accDel() { const m = UI.modal; if (!deleteAccount(m.id)) { toast("It has entries (or is the last account). Delete its entries first."); return; } UI.modal = null; toast("Account deleted"); commit(); },
  catsOpen() { openModal("cats"); },
  catNew(el) { UI.modal.edit = { kind: el.dataset.kind }; UI.modal.d = { name: "", budget: "" }; render(); },
  catEdit(el) { const c = find("cats", el.dataset.id); if (!c) return; UI.modal.edit = { id: c.id, kind: c.kind }; UI.modal.d = { name: c.name, budget: +c.budget > 0 ? String(c.budget) : "" }; render(); },
  catBack() { UI.modal.edit = null; render(); },
  catSave() { const m = UI.modal; const name = (m.d.name || "").trim(); if (!name) { toast("Give it a name"); return; } saveCat(m.edit.id, name, m.edit.kind, num(m.d.budget)); m.edit = null; commit(); },
  async catDel() { const m = UI.modal; if (!await ask("Delete this category? Its entries stay (shown as Other).")) return; removeId("cats", m.edit.id); m.edit = null; commit(); },
  goalNew() { openModal("goal", { d: { name: "", cur: mainCur(), target: "" } }); },
  goalEdit(el) { const g = find("goals", el.dataset.id); if (g) openModal("goal", { id: g.id, d: { name: g.name, cur: g.cur, target: +g.target > 0 ? String(g.target) : "" } }); },
  goalSave() { const m = UI.modal; const name = (m.d.name || "").trim(); if (!name) { toast("Give the goal a name"); return; } saveGoal(m.id, name, m.d.cur, num(m.d.target)); UI.modal = null; UI.showGoals = true; commit(); },
  async goalDel() { if (!await ask("Delete this goal?")) return; removeId("goals", UI.modal.id); UI.modal = null; toast("Goal deleted"); commit(); },
  goalMove(el) { const g = find("goals", el.dataset.id); if (!g) return; const sign = +el.dataset.sign; openModal("amount", { title: (sign > 0 ? "Put into " : "Take out of ") + g.name, cur: g.cur, then: "goal", id: g.id, sign, d: { v: "" } }); },
  planDays(el) { UI.planDays = +el.dataset.v; render(); },
  planNew(el) { UI.planEdit = { kind: el.dataset.kind || "in", owe: true, repeat: el.dataset.kind === "bill" ? "monthly" : "", task: el.dataset.task || "" }; if (UI.view !== "money") UI.view = "money"; render(); const i = $("#p_title"); if (i) { i.focus(); i.scrollIntoView({ block: "center" }); } },
  planEdit(el) { const p = find("plans", el.dataset.id); if (!p) return; UI.planEdit = JSON.parse(JSON.stringify(p)); if (UI.view !== "money") UI.view = "money"; render(); const i = $("#p_title"); if (i) i.scrollIntoView({ block: "center" }); },
  planCancel() { UI.planEdit = null; render(); },
  planKind(el) { UI.planEdit = Object.assign(readPlan(), { kind: el.dataset.v }); if (el.dataset.v === "bill" && !UI.planEdit.repeat) UI.planEdit.repeat = "monthly"; render(); },
  planOwe(el) { UI.planEdit = Object.assign(readPlan(), { owe: el.dataset.v === "1" }); render(); },
  planMakeTask() {
    const p = readPlan(); const verb = { in: "Collect", bill: "Pay", out: "Buy" }[p.kind] || (p.owe !== false ? "Pay back" : "Collect");
    const t = addTask(verb + ": " + (p.title || "").trim(), "inbox", p.date || "", { prio: 2 }); p.task = t.id; UI.planEdit = p; toast("Task created ✓"); commit();
  },
  planSave() {
    const p = readPlan(); const a = num(p.amt);
    if (!(a > 0)) { $("#p_why").textContent = "Type the amount first"; $("#p_amt").focus(); return; }
    const kn = { in: "Expected income", bill: "Bill", out: "Planned spending" };
    const title = (p.title || "").trim() || (p.who || "").trim() || kn[p.kind] || (p.owe === false ? "Owed to me" : "I owe");
    const v = { kind: p.kind, title, amt: a, cur: p.cur, date: p.date || "", repeat: p.kind === "bill" ? (p.repeat ?? "monthly") : "", who: (p.who || "").trim(), cat: p.cat || "", owe: p.owe !== false, task: p.task || "" };
    const old = p.id && find("plans", p.id);
    if (old) Object.assign(old, v); else plans().push(Object.assign({ id: newId(), done: "", paid: 0 }, v));
    UI.planEdit = null; toast("Saved ✓"); commit();
  },
  planAct(el) {
    const p = find("plans", el.dataset.id); if (!p) return;
    if (p.kind === "debt") { openModal("amount", { title: planSign(p) > 0 ? "How much came in?" : "How much did you pay?", cur: p.cur || mainCur(), then: "plan", id: p.id, d: { v: String(planLeft(p)) } }); return; }
    completePlan(p.id); toast("Written in Money ✓"); commit();
  },
  async planDel(el) { if (!await ask("Delete this plan? Money already written in Money stays.")) return; removeId("plans", el.dataset.id); UI.planEdit = null; commit(); },
});
Object.assign(ENTER, {
  saveTx() { A.saveTx(); }, planSave() { A.planSave(); },
  accSave() { readModal(); A.accSave(); }, goalSave() { readModal(); A.goalSave(); }, catSave() { readModal(); A.catSave(); },
});
