Qarun for Windows 1.5.0

Double-click Qarun.exe. The first time, Windows may ask to allow it on the network: allow it on
private networks, so your phone can link over your Wi-Fi.

Your data stays on this computer, in %LOCALAPPDATA%\Qarun.
Phone app: Qarun on Google Play. Made by AmraniHub: https://github.com/AmraniHub
