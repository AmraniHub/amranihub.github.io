"use strict";
// The frame: side menu, page drawing, dialogs, shared pieces, clicks and keys, reminders, the running clock.

const NAV = [["today", "🏆", "Today"], ["tasks", "✅", "Tasks"], ["time", "⏱", "Time"], ["money", "💰", "Money"], ["settings", "⚙", "Settings & phone"]];

function setSide(ok) {
  const pairs = (S && S.pairs) || [];
  const last = pairs.reduce((m, p) => Math.max(m, p.seen || 0), 0);
  const foot = !S ? '<span class="dot"></span>Server not running' :
    pairs.length ? `<span class="dot ${ok !== false && Date.now() - last < 60000 ? "ok" : ""}"></span>${h(pairs[0].dev || "Phone")}<br><span class="muted">synced ${ago(last)}</span>` :
      '<span class="dot"></span>No phone linked';
  $("#side").innerHTML = `<div class="brand"><img src="/star.svg" alt=""><b>Qarun</b></div>` +
    NAV.map(([v, e, n]) => `<div class="nav ${UI.view === v ? "on" : ""}" data-go="${v}"><span class="e">${e}</span>${n}</div>`).join("") +
    `<div class="side-foot" data-go="settings">${foot}</div>`;
}

function render() {
  if (!S) return;
  const a = document.activeElement; const fid = a && a.id; const val = a && a.value; const sel = a && a.selectionStart;
  const scroll = $("#main").scrollTop; const mscroll = $("#modal .box") ? $("#modal .box").scrollTop : 0;
  setSide();
  const empty = !Object.keys(records(R)).length;
  $("#main").innerHTML = empty && UI.view !== "settings" ? welcome() : (VIEW[UI.view] || VIEW.today)();
  $("#main").scrollTop = scroll;
  $("#modal").innerHTML = UI.modal && MODAL[UI.modal.t] ? `<div class="back" data-a="closeModal"></div><div class="box">${MODAL[UI.modal.t](UI.modal)}</div>` : "";
  $("#modal").style.display = UI.modal ? "block" : "none";
  if ($("#modal .box")) $("#modal .box").scrollTop = mscroll;
  if (fid) { const el = document.getElementById(fid); if (el) { el.focus(); if (val != null && el.value !== val && el.tagName !== "SELECT") el.value = val; try { if (sel != null) el.setSelectionRange(sel, sel); } catch (e) { } } }
  keepUi();
}

function welcome() {
  return `<h1>Qarun</h1><div class="creed">Time and money: spend both like an investor.</div>
  <div class="now"><div class="lab">START</div><div class="ti">Bring your phone's Qarun here</div>
  <p class="muted">Link your phone once and everything on it (tasks, time, money, habits) appears here, and stays the same on both.</p>
  <div class="btns"><button class="btn" data-go="settings">📱 Link my phone</button><button class="ghost" data-a="seed">Start without a phone</button></div></div>`;
}

// ---------------------------------------------------------------- dialogs
const MODAL = {};
function openModal(t, data) { UI.modal = Object.assign({ t }, data || {}); render(); setTimeout(() => { const f = $("#modal [autofocus]"); if (f) f.focus(); }, 0); }
function closeModal() {
  const m = UI.modal;
  if (m && m.t === "confirm") { UI.modal = m.prev || null; m.res(false); render(); return; }
  UI.modal = null; render();
}
/** Qarun's own "are you sure?" (on top of any open dialog, which comes back if you cancel). Resolves true on yes. */
function ask(text, yes) {
  if (!yes) yes = /^Unlink/.test(text) ? "Unlink" : /^Quit/.test(text) ? "Quit" : /^Throw/.test(text) ? "Throw it away" : /deleted\.|older than|more than \d+ days/.test(text) && !/^Delete/.test(text) ? "Clear" : "Delete";
  return new Promise((res) => { UI.modal = { t: "confirm", text, yes, prev: UI.modal, res }; render(); });
}
MODAL.confirm = (m) => dlg("Are you sure?", `<p style="margin:4px 0;font-size:16px">${h(m.text)}</p>`,
  `<button class="ghost" data-a="closeModal">Cancel</button><button class="btn danger" data-a="confirmYes" autofocus>${h(m.yes)}</button>`);
A.confirmYes = () => { const m = UI.modal; UI.modal = m.prev || null; render(); m.res(true); };
/** Copies what is typed in the dialog into its draft, so a redraw (a picked colour) keeps it. */
function readModal() {
  if (!UI.modal) return;
  const d = UI.modal.d || (UI.modal.d = {});
  document.querySelectorAll("#modal [data-m]").forEach((el) => { d[el.dataset.m] = el.type === "checkbox" ? el.checked : el.value; });
}
const dlg = (title, body, foot) => `<div class="mhead"><h2>${h(title)}</h2><button class="x" data-a="closeModal">✕</button></div><div class="mbody">${body}</div>${foot ? `<div class="mfoot">${foot}</div>` : ""}`;

// ---------------------------------------------------------------- shared pieces
const pill = (label, on, attrs, color) => `<span class="pill ${on ? "on" : ""}" ${attrs || ""} ${on && color ? `style="border-color:${color};color:${color};background:${color}22"` : ""}>${label}</span>`;
const colorPick = (cur) => `<div class="swatches">${LIST_COLORS.map((c, i) => `<button class="sw ${cur === i ? "on" : ""}" style="background:${c}" data-a="mset" data-f="color" data-v="${i}" data-num="1"></button>`).join("")}</div>`;
const iconPick = (icons, cur) => `<div class="icons">${icons.map((e) => `<button class="ic ${cur === e ? "on" : ""}" data-a="mset" data-f="icon" data-v="${h(e)}">${e}</button>`).join("")}</div>`;
const opt = (v, cur, label) => `<option value="${h(v)}" ${String(v) === String(cur ?? "") ? "selected" : ""}>${h(label)}</option>`;
const curOptions = (cur) => `<optgroup label="Money">${FIAT.map(([c, s]) => opt(c, cur, s + " " + c)).join("")}</optgroup><optgroup label="Crypto">${CRYPTO.map(([c, s]) => opt(c, cur, s + " " + c)).join("")}</optgroup>`;
const bar = (frac, color) => `<div class="bar"><i style="width:${Math.max(0, Math.min(100, frac * 100))}%;${color ? "background:" + color : ""}"></i></div>`;

function taskRow(t, o = {}) {
  const n = subs(t).length, dn = subs(t).filter((x) => x.done).length;
  const late = !isDone(t) && t.due && t.due < today();
  const bits = [];
  if (t.due && o.showDue !== false) bits.push(dayLabel(t.due) + (t.time ? " " + t.time : ""));
  else if (t.time) bits.push("🕘 " + t.time);
  if (t.repeat) bits.push("🔁 " + repeatName(t.repeat));
  if (o.showList !== false && t.list !== "inbox") bits.push(listIcon(t.list) + " " + h(listName(t.list)));
  if (t.act && act(t.act)) bits.push(actIcon(t.act) + " " + h(actName(t.act)));
  if (n) bits.push(`☑ ${dn}/${n}`);
  if (t.remind > 0 && t.time) bits.push("🔔");
  if ((t.note || "").trim()) bits.push("📝");
  const nx = !isDone(t) && nextSub(t);
  const picked = UI.sel.includes(t.id);
  const ring = isDone(t) ? "var(--green)" : t.prio > 0 ? PRIO_COLORS[Math.min(3, t.prio)] : "var(--muted)";
  return `<div class="row click ${isDone(t) ? "done" : ""} ${UI.task === t.id && UI.view === "tasks" ? "sel" : ""} ${picked ? "picked" : ""}" data-a="openTask" data-id="${t.id}">
    <input type="checkbox" class="pick" title="Select" data-a="sel" data-id="${t.id}" ${picked ? "checked" : ""}>
    <button class="check ${isDone(t) ? "on" : ""}" style="border-color:${ring};${isDone(t) ? "background:" + ring : ""}" data-a="toggle" data-id="${t.id}">${isDone(t) ? "✓" : ""}</button>
    <div class="grow"><div class="t">${h(t.title)}</div>${bits.length ? `<div class="meta ${late ? "red" : ""}">${bits.join("  ·  ")}</div>` : ""}
    ${nx ? `<div class="meta gold">→ ${h(nx.t)}</div>` : ""}</div></div>`;
}

function clock() {
  const r = running(); if (!r) return "";
  let ms = elapsed(r);
  if (r.focus) ms = Math.max(0, r.focus * 60000 - ms);
  const s = Math.floor(ms / 1000);
  return (s >= 3600 ? Math.floor(s / 3600) + ":" : "") + pad(Math.floor((s % 3600) / 60)) + ":" + pad(s % 60);
}

/** The running timer: the clock, what it counts for (changeable), the task's or the activity's steps. */
function runningCard() {
  const r = running(); const t = r.task ? find("tasks", r.task) : null;
  const goal = (act(r.act) || {}).goal || 0;
  const week = minutesWeek(r.act) + Math.floor(elapsed(r) / 60000);
  return `<div class="now" style="border-color:${actColor(r.act)}"><div class="lab">${r.focus ? "FOCUS · " + r.focus + " MIN" : "TIMER RUNNING"} ${r.paused ? '<span class="amber">· PAUSED</span>' : ""}</div>
    <div class="line" style="display:flex;gap:10px;align-items:center;margin:6px 0"><span style="font-size:24px">${actIcon(r.act)}</span>
      <select id="runAct" data-change="runAct" class="ti-sel">${acts().map((a) => opt(a.id, r.act, a.name)).join("")}</select>
      ${t ? `<span class="muted">· ${h(t.title)}</span>` : ""}</div>
    <div class="clock" data-clock>${clock()}</div>
    ${goal ? `<div class="small ${week >= goal ? "green" : "muted"}">This week ${fmtMin(week)} of ${fmtMin(goal)}</div>` : ""}
    <div class="btns" style="margin-top:10px">${r.paused ? '<button class="btn" data-a="resume">▶ Resume</button>' : '<button class="ghost gold" data-a="pause">⏸ Pause</button>'}
    <button class="btn" data-a="stop">■ Stop and save</button><button class="ghost" data-a="cancelTimer">Cancel without saving</button></div>
    <div style="margin-top:12px">${t ? focusSteps(t) : actStepsBox(r.act, true)}</div></div>`;
}
function focusSteps(t) {
  const ss = subs(t);
  return `<div class="stepbox"><div class="kicker">☑ ${h(t.title)} ${ss.length ? "· " + ss.filter((x) => x.done).length + "/" + ss.length : ""}</div>
    ${ss.map((x) => `<div class="step"><button class="check sq ${x.done ? "on" : ""}" data-a="sub" data-id="${t.id}" data-s="${x.id}">${x.done ? "✓" : ""}</button><span class="${x.done ? "muted strike" : ""}">${h(x.t)}</span></div>`).join("")}
    <input type="text" id="addStepRun" placeholder="+ Add a step (Enter)" data-enter="addStep" data-id="${t.id}" style="width:100%">
    <div class="btns" style="margin-top:8px"><button class="ghost green" data-a="toggle" data-id="${t.id}">✓ Task done</button></div></div>`;
}
/** An activity's own steps and its linked tasks (inside the timer, and in the activity's editor). */
function actStepsBox(id, inTimer) {
  const steps = actSubs(id); const left = steps.filter((x) => !x.done).length;
  const linked = tasksForAct(id); const runTask = (running() || {}).task || "";
  const ordered = steps.filter((x) => !x.done).concat(steps.filter((x) => x.done));
  return `<div class="stepbox"><div class="kicker">TO DO IN ${h(actName(id).toUpperCase())} ${steps.length ? `<span class="${left ? "gold" : "green"}">${steps.length - left}/${steps.length}</span>` : ""}</div>
    ${linked.map((t) => `<div class="step"><button class="check" style="border-color:${prioColor(t)}" data-a="toggle" data-id="${t.id}"></button>
      <span class="grow" style="cursor:pointer" data-a="openTask" data-id="${t.id}">${h(t.title)} <span class="meta">${t.due ? dayLabel(t.due) : ""}</span></span>
      ${inTimer ? (runTask === t.id ? '<b class="gold small">NOW</b>' : `<button class="ghost small" data-a="runTask" data-id="${t.id}">▶ Work on it</button>`) : ""}</div>`).join("")}
    ${!steps.length && !linked.length ? `<div class="muted small">${inTimer ? "What will you do in this session? Add it below." : "Lessons, chapters, drills: what you work through in this activity."}</div>` : ""}
    ${ordered.map((x, i) => `<div class="step"><button class="check sq ${x.done ? "on" : ""}" data-a="actSub" data-id="${id}" data-s="${x.id}">${x.done ? "✓" : ""}</button>
      <span class="grow ${x.done ? "muted strike" : ""}">${h(x.t)}</span>${!x.done && i === 0 ? '<b class="gold small">NEXT</b>' : ""}
      ${inTimer ? "" : `<button class="x" data-a="actSubDel" data-id="${id}" data-s="${x.id}">×</button>`}</div>`).join("")}
    <input type="text" id="addActStep_${id}" placeholder="+ Add a step (Enter)" data-enter="addActStep" data-id="${id}" style="width:100%">
    ${steps.some((x) => x.done) ? `<button class="ghost small" style="margin-top:6px" data-a="actSubClear" data-id="${id}">Clear ticked steps</button>` : ""}</div>`;
}

// ---------------------------------------------------------------- shared actions
Object.assign(A, {
  async seed() { adopt(await api("/ui/seed", {})); },
  closeModal() { closeModal(); },
  mset(el) { const d = UI.modal.d || (UI.modal.d = {}); d[el.dataset.f] = el.dataset.num ? +el.dataset.v : el.dataset.v; render(); },
  toggle(el) { finishTask(el.dataset.id); commit(); },
  sel(el, ev) { const id = el.dataset.id; UI.sel = UI.sel.includes(id) ? UI.sel.filter((x) => x !== id) : UI.sel.concat([id]); render(); },
  openTask(el, ev) {
    if (UI.sel.length) { A.sel(el); return; }
    UI.task = el.dataset.id;
    if (UI.view !== "tasks") { UI.view = "tasks"; const t = find("tasks", UI.task); if (t && !["today", "upcoming", "search", "done"].includes(UI.tview) && UI.tview !== "list:" + t.list) UI.tview = "today"; }
    render();
  },
  sub(el) { const t = find("tasks", el.dataset.id); const x = t && subs(t).find((y) => y.id === el.dataset.s); if (x) { x.done = !x.done; commit(); } },
  focus(el) { const t = find("tasks", el.dataset.id); if (!t) return; openModal("focus", { id: t.id, d: { act: actForTask(t), dur: +setting("focusDur", "25") || 0, keep: true } }); },
  later(el) { const t = find("tasks", el.dataset.id); if (t) { t.due = addDays(today(), 1); toast("Moved to tomorrow"); commit(); } },
  moveLate(el) { const d = addDays(today(), +el.dataset.d); const l = lateTasks(); l.forEach((t) => (t.due = d)); toast(l.length + (el.dataset.d === "0" ? " moved to today" : " moved to tomorrow")); commit(); },
  pause() { pauseTimer(); commit(); },
  resume() { resumeTimer(); commit(); },
  stop() {
    const r = running(); if (!r) return;
    if (elapsed(r) > 3 * 3600000) { openModal("longTimer", { d: { keep: Math.floor(elapsed(r) / 60000) } }); return; }
    const name = actName(r.act); const m = stopTimer(); toast(m >= 1 ? "+" + fmtMin(m) + "  " + name : "Under a minute: not saved"); commit();
  },
  async cancelTimer() { if (!await ask("Throw this timer away without saving the time?")) return; delete R.run; toast("Timer cancelled"); commit(); },
  runTask(el) { const r = running(); if (r) { r.task = el.dataset.id; commit(); } },
  actSub(el) { const x = actSubs(el.dataset.id).find((y) => y.id === el.dataset.s); if (x) { x.done = !x.done; commit(); } },
  actSubDel(el) { const a = act(el.dataset.id); if (a) { a.sub = actSubs(a.id).filter((y) => y.id !== el.dataset.s); commit(); } },
  actSubClear(el) { const a = act(el.dataset.id); if (a) { a.sub = actSubs(a.id).filter((y) => !y.done); commit(); } },
  editCreed() { openModal("creed", { d: { v: creed() } }); },
});
Object.assign(ENTER, {
  addStep(el) { const v = el.value.trim(); const t = find("tasks", el.dataset.id); if (!v || !t) return; subs(t).push({ id: newId(), t: v, done: false }); el.value = ""; commit(); },
  addActStep(el) { const v = el.value.trim(); if (!v || !act(el.dataset.id)) return; actSubs(el.dataset.id).push({ id: newId(), t: v, done: false }); el.value = ""; commit(); },
});
Object.assign(CHANGE, {
  runAct(el) { const r = running(); if (!r) return; r.act = el.value; setSetting("lastAct", el.value); const t = r.task && find("tasks", r.task); if (t) setSetting("la_" + t.list, el.value); commit(); },
});

MODAL.focus = (m) => {
  const t = find("tasks", m.id); if (!t) return dlg("Focus", "Task not found.");
  const d = m.d;
  return dlg("Focus on this task", `<div class="ti" style="font:600 18px var(--serif)">${h(t.title)}</div>
    <div class="kicker" style="margin-top:12px">HOW LONG</div>
    <div>${[15, 25, 45, 60, 90].map((x) => pill(fmtMin(x), +d.dur === x, `data-a="mset" data-f="dur" data-v="${x}" data-num="1"`)).join("")}${pill("⏱ No limit", +d.dur === 0, `data-a="mset" data-f="dur" data-v="0" data-num="1"`)}</div>
    ${+d.dur > 0 ? `<div class="line"><input type="number" min="5" step="5" data-m="dur" value="${d.dur}" style="width:90px"> min</div>` : ""}
    <div class="kicker" style="margin-top:12px">COUNTS FOR</div>
    <div>${acts().map((a) => pill(actIcon(a.id) + " " + h(a.name), d.act === a.id, `data-a="mset" data-f="act" data-v="${a.id}"`, actColor(a.id))).join("")}</div>
    <label class="chk"><input type="checkbox" data-m="keep" ${d.keep ? "checked" : ""}> Always count ${h(listName(t.list))} tasks here</label>`,
    `<button class="ghost" data-a="closeModal">Cancel</button><button class="btn" data-a="focusGo" ${d.act ? "" : "disabled"}>▶ Start ${+d.dur > 0 ? fmtMin(+d.dur) : ""}</button>`);
};
A.focusGo = () => {
  const m = UI.modal; const t = find("tasks", m.id); const d = m.d; const dur = Math.max(0, parseInt(d.dur, 10) || 0);
  if (!t || !d.act) return;
  if (d.keep) setSetting("la_" + t.list, d.act);
  t.act = d.act; setSetting("focusDur", String(dur));
  startTimer(d.act, dur, t.id); notified = false; UI.modal = null; commit();
};
MODAL.longTimer = (m) => {
  const r = running(); if (!r) return dlg("Timer", "No timer is running.");
  const total = Math.floor(elapsed(r) / 60000);
  return dlg(`This timer ran ${fmtMin(total)}`, `<p class="muted">Did you forget it running? Keep only the time you really spent on ${h(actName(r.act))}.</p>
    <div class="line"><input type="number" min="0" max="${total}" data-m="keep" value="${m.d.keep}" style="width:100px"> min</div>
    <div>${[30, 60, 90, 120].filter((x) => x < total).map((x) => pill(fmtMin(x), +m.d.keep === x, `data-a="mset" data-f="keep" data-v="${x}" data-num="1"`)).join("")}${pill("All " + fmtMin(total), +m.d.keep === total, `data-a="mset" data-f="keep" data-v="${total}" data-num="1"`)}</div>`,
    `<button class="ghost" data-a="closeModal">Keep it running</button><button class="btn" data-a="longSave">Save</button>`);
};
A.longSave = () => { const r = running(); if (!r) return closeModal(); const total = Math.floor(elapsed(r) / 60000); const k = Math.max(0, Math.min(total, parseInt(UI.modal.d.keep, 10) || 0)); const name = actName(r.act); stopTimer(k); UI.modal = null; toast(k >= 1 ? "+" + fmtMin(k) + "  " + name : "Nothing saved"); commit(); };
MODAL.creed = (m) => dlg("Your line", `<input type="text" data-m="v" value="${h(m.d.v)}" style="width:100%" autofocus data-enter="creedSave">`,
  `<button class="ghost" data-a="closeModal">Cancel</button><button class="btn" data-a="creedSave">Save</button>`);
A.creedSave = () => { const v = (UI.modal.d.v || "").trim(); if (v) setSetting("creed", v); UI.modal = null; commit(); };
ENTER.creedSave = () => { readModal(); A.creedSave(); };

// ---------------------------------------------------------------- clicks and keys
document.addEventListener("click", (ev) => {
  const go = ev.target.closest("[data-go]");
  if (go) { UI.view = go.dataset.go; UI.sel = []; if (S) S.paired_now = ""; render(); try { if (window.Notification && Notification.permission === "default") Notification.requestPermission(); } catch (e) { } return; }
  const el = ev.target.closest("[data-a]");
  if (!el || el.disabled) return;
  if (el.closest("#modal")) readModal();
  if (el.type !== "checkbox") ev.preventDefault();
  ev.stopPropagation();
  const f = A[el.dataset.a];
  if (f) Promise.resolve(f(el, ev)).catch((e) => toast(String(e.message || e)));
}, true);
document.addEventListener("keydown", (ev) => {
  const el = ev.target;
  if (ev.key === "Escape") { if (UI.modal) closeModal(); else if (UI.sel.length) { UI.sel = []; render(); } return; }
  if (ev.key === "Enter" && el.dataset && el.dataset.enter && ENTER[el.dataset.enter]) { ev.preventDefault(); if (el.closest("#modal")) readModal(); ENTER[el.dataset.enter](el); }
  else if (ev.key === "Enter" && el.dataset && el.dataset.change && el.tagName === "INPUT") el.blur();
});
document.addEventListener("change", (ev) => { const el = ev.target; if (el.dataset && el.dataset.change && CHANGE[el.dataset.change]) { if (el.closest("#modal")) readModal(); CHANGE[el.dataset.change](el); } });

// ---------------------------------------------------------------- the clock, reminders, midnight
let notified = false;
function notify(title, body) {
  toast(body);
  try { if (window.Notification && Notification.permission === "granted") new Notification(title, { body, icon: "/star.svg" }); } catch (e) { }
}
setInterval(() => {
  const r = running();
  document.querySelectorAll("[data-clock]").forEach((el) => (el.textContent = clock()));
  if (r && r.focus && !r.paused && !notified && elapsed(r) >= r.focus * 60000) { notified = true; notify("Qarun", "⏰ Focus time is up: " + actName(r.act) + ". Stop to save it."); }
  if (S && S.pairing && UI.view === "settings") { S.pairing.left = Math.max(0, S.pairing.left - 1); if (S.pairing.left % 5 === 0) render(); }
}, 1000);
/** Task reminders ring here too while this window is open (at the task's time, minus its "remind" minutes). */
function checkReminders() {
  if (!S) return;
  let fired = {}; try { fired = JSON.parse(localStorage.getItem("qd_fired") || "{}"); } catch (e) { }
  const now = Date.now();
  for (const t of tasks()) {
    if (isDone(t) || !t.due || !t.time) continue;
    const m = hmMin(t.time); if (m == null) continue;
    const at = parseD(t.due).getTime() + m * 60000 - (t.remind || 0) * 60000;
    const key = t.id + "|" + t.due + "|" + t.time + "|" + (t.remind || 0);
    if (now >= at && now - at < 15 * 60000 && !fired[key]) { fired[key] = now; notify("Qarun", "🔔 " + t.title + (t.remind ? " (at " + t.time + ")" : "")); }
  }
  for (const k of Object.keys(fired)) if (now - fired[k] > 3 * 86400000) delete fired[k];
  try { localStorage.setItem("qd_fired", JSON.stringify(fired)); } catch (e) { }
}
setInterval(checkReminders, 20000);
let lastDay = today();
setInterval(() => { if (today() !== lastDay) { lastDay = today(); render(); } }, 30000);
