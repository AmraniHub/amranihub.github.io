"use strict";
// Tasks: Today, Upcoming, Timeline, Calendar, Ideas, History, Search and every list; select many; the task panel.

const TVIEWS = [["today", "☀️", "Today"], ["upcoming", "📆", "Upcoming"], ["timeline", "🕘", "Timeline"], ["calendar", "📅", "Calendar"],
  ["ideas", "💡", "Ideas"], ["done", "✅", "History"], ["search", "🔍", "Search"]];

function tviewCount(v) {
  if (v === "today") return todayTasks().length;
  if (v === "upcoming") return upcoming().length;
  if (v === "ideas") return ideaFolders().reduce((n, f) => n + ideasIn(f.id).length, 0);
  if (v.startsWith("list:")) return inList(v.slice(5)).length;
  return "";
}

VIEW.tasks = () => {
  const V = UI.tview;
  if (V.startsWith("list:") && !taskLists().some((l) => "list:" + l.id === V)) UI.tview = "today";
  const t = UI.task && find("tasks", UI.task);
  if (UI.task && !t) UI.task = null;
  const nav = `<div class="card">${TVIEWS.map(([v, e, n]) => `<div class="row click ${UI.tview === v ? "sel" : ""}" data-a="tview" data-v="${v}"><span>${e}</span><div class="grow t">${n}</div><span class="meta">${tviewCount(v) || ""}</span></div>`).join("")}
    <div class="row" style="padding:8px 14px 2px"><span class="kicker" style="margin:0">LISTS</span></div>
    ${taskLists().map((l) => `<div class="row click ${UI.tview === "list:" + l.id ? "sel" : ""}" data-a="tview" data-v="list:${l.id}"><span style="color:${listColor(l.id)}">${listIcon(l.id)}</span><div class="grow t">${h(l.name)}</div><span class="meta">${inList(l.id).length || ""}</span><button class="x" data-a="listEdit" data-id="${l.id}" title="Edit list">✎</button></div>`).join("")}
    <div class="row click" data-a="listNew"><span class="gold">＋</span><div class="grow gold">New list</div></div></div>`;
  const wide = ["timeline", "calendar", "ideas"].includes(UI.tview) && !t;
  return `<h1>Tasks</h1><div class="grid ${wide ? "cols2w" : "cols3"}" style="margin-top:14px">${nav}<div>${bulkBar()}${tasksMiddle()}</div>
    ${wide ? "" : `<div class="detail">${t ? taskDetail(t) : '<div class="card pad muted">Click a task to see and change it. Tick the small box on a row to select several.</div>'}</div>`}</div>`;
};

function addBox(placeholder, due, list) {
  return `<div class="add"><input type="text" id="addTask" placeholder="${h(placeholder)} (Enter)" data-enter="addTask" data-due="${h(due)}" data-list="${h(list)}"><button class="ghost gold" data-a="newTaskFull" data-due="${h(due)}" data-list="${h(list)}" title="New task with date, time, priority…">＋ details</button></div>`;
}

function tasksMiddle() {
  const V = UI.tview; const td = today();
  if (V === "today") { const l = todayTasks(); return `<div class="kicker">Today · ${l.length} left</div><div class="card">${l.map((x) => taskRow(x)).join("") || '<div class="empty">Nothing left for today. Add what matters most.</div>'}${addBox("Add a task for today", td, "inbox")}</div>`; }
  if (V === "upcoming") {
    const by = {}; upcoming().forEach((x) => (by[x.due] = by[x.due] || []).push(x));
    return `<div class="card sec">${addBox("Add a task for tomorrow", addDays(td, 1), "inbox")}</div>` + (Object.keys(by).length ? Object.entries(by).map(([d, l]) => `<div class="kicker">${dayLabel(d)}</div><div class="card sec">${l.map((x) => taskRow(x, { showDue: false })).join("")}</div>`).join("") : '<div class="card"><div class="empty">Nothing planned after today.</div></div>');
  }
  if (V === "done") {
    const all = doneTasks(); const shown = all.slice(0, 300); const by = {};
    shown.forEach((x) => (by[x.done] = by[x.done] || []).push(x));
    return (all.length ? "" : '<div class="card"><div class="empty">Every task you finish shows here, day by day.</div></div>') +
      Object.entries(by).map(([d, l]) => { const mins = minutes(null, d, d); return `<div class="kicker">${dayLabel(d)} · ${l.length} done${mins ? " · ⏱ " + fmtMin(mins) : ""}</div><div class="card sec">${l.map((x) => taskRow(x, { showDue: false })).join("")}</div>`; }).join("") +
      (all.length > shown.length ? `<div class="muted small">Showing the latest ${shown.length} of ${all.length}.</div>` : "") +
      (all.length ? `<div class="btns"><button class="ghost" data-a="clearHist" data-v="old">Clear older than 30 days</button><button class="ghost red" data-a="clearHist" data-v="all">Clear all history</button></div>` : "");
  }
  if (V === "search") {
    const q = (UI.query || "").trim().toLowerCase();
    const hits = q ? tasks().filter((x) => (x.title || "").toLowerCase().includes(q) || (x.note || "").toLowerCase().includes(q)).sort((a, b) => isDone(a) - isDone(b) || (a.due || "9999").localeCompare(b.due || "9999")) : [];
    return `<div class="card pad sec"><input type="text" id="q" data-input="search" value="${h(UI.query || "")}" placeholder="Search all tasks and notes" style="width:100%" autofocus></div>
      <div class="kicker">${q ? "Found " + hits.length : "Search"}</div><div class="card">${q ? (hits.map((x) => taskRow(x)).join("") || '<div class="empty">Nothing found.</div>') : '<div class="empty">Type a word from a task or its note.</div>'}</div>`;
  }
  if (V === "calendar") return calendarView();
  if (V === "timeline") return timelineView();
  if (V === "ideas") return ideasView();
  const id = V.slice(5); const l = inList(id);
  return `<div class="kicker">${listIcon(id)} ${h(listName(id))} · ${l.length} <button class="x" data-a="listEdit" data-id="${id}">✎ Edit list</button></div><div class="card">${l.map((x) => taskRow(x, { showList: false })).join("") || '<div class="empty">Empty. Add a task below.</div>'}${addBox("Add to " + listName(id), "", id)}</div>`;
}

// ---------------------------------------------------------------- select many
function bulkBar() {
  if (!UI.sel.length) return "";
  const n = UI.sel.length;
  return `<div class="bulk"><b class="gold">${n} selected</b>
    <button class="ghost green" data-a="bulk" data-v="done">✓ Done</button>
    <input type="date" id="bulkDate" data-change="bulkDate" title="New date">
    <button class="ghost" data-a="bulk" data-v="today">Today</button><button class="ghost" data-a="bulk" data-v="tomorrow">Tomorrow</button><button class="ghost" data-a="bulk" data-v="nodate">No date</button>
    <select id="bulkList" data-change="bulkList"><option value="">📁 Move to…</option>${lists().map((l) => opt(l.id, "", (l.idea ? "💡 " : "") + l.name)).join("")}</select>
    <select id="bulkPrio" data-change="bulkPrio"><option value="">⚑ Priority…</option>${PRIO_NAMES.map((p, i) => opt(i, "", p)).join("")}</select>
    <button class="ghost red" data-a="bulk" data-v="delete">🗑 Delete</button>
    <button class="ghost" data-a="bulk" data-v="all">All</button><button class="ghost" data-a="bulk" data-v="none">✕</button></div>`;
}
function visibleIds() {
  const V = UI.tview;
  const l = V === "today" ? todayTasks() : V === "upcoming" ? upcoming() : V === "done" ? doneTasks().slice(0, 300) : V.startsWith("list:") ? inList(V.slice(5)) : V === "ideas" && UI.folder ? ideasIn(UI.folder) : [];
  return l.map((x) => x.id);
}

// ---------------------------------------------------------------- calendar
function calendarView() {
  const td = today(); const ym = UI.calMonth || td.slice(0, 7); const day = UI.calDay || td;
  const lead = (parseD(ym + "-01").getDay() + 6) % 7; const n = monthLen(ym);
  const open = {}, done = {};
  tasks().forEach((x) => { if (!isDone(x) && x.due) open[x.due] = (open[x.due] || 0) + 1; if (isDone(x)) done[x.done] = (done[x.done] || 0) + 1; });
  let cells = ""; for (let i = 0; i < lead; i++) cells += "<span></span>";
  for (let i = 1; i <= n; i++) {
    const d = ym + "-" + pad(i); const o = open[d] || 0;
    cells += `<button class="cal ${d === day ? "on" : ""} ${d === td ? "today" : ""}" data-a="calDay" data-v="${d}"><b>${i}</b><span>${o ? `<i class="${d < td ? "red" : "gold"}">●${o > 1 ? o : ""}</i>` : ""}${done[d] ? `<i class="green">✓${done[d] > 1 ? done[d] : ""}</i>` : ""}</span></button>`;
  }
  const list = tasksOn(day);
  return `<div class="line" style="display:flex;align-items:center;gap:8px"><button class="ghost" data-a="calMonth" data-by="-1">‹</button><h2 style="flex:1;text-align:center;margin:0">${monthName(ym)}</h2><button class="ghost" data-a="calMonth" data-by="1">›</button>
    ${ym !== td.slice(0, 7) || day !== td ? '<button class="ghost gold" data-a="calToday">Today</button>' : ""}</div>
    <div class="card pad sec"><div class="calgrid big">${DOW.map((x) => `<span class="muted small">${x}</span>`).join("")}${cells}</div></div>
    <div class="kicker">${dayLabel(day)} · ${list.length}</div><div class="card">${list.map((x) => taskRow(x, { showDue: false })).join("") || '<div class="empty">Nothing on this day.</div>'}${addBox("Add a task on " + dayLabel(day), day, "inbox")}</div>`;
}

// ---------------------------------------------------------------- the day timeline
function daySlots(day) {
  const timed = [], allDay = [];
  for (const t of tasksOn(day)) {
    const m = hmMin(t.time); const c = t.prio > 0 ? PRIO_COLORS[Math.min(3, t.prio)] : listColor(t.list);
    if (m == null) allDay.push({ kind: "task", t, c }); else timed.push({ kind: "task", t, c, from: m, to: m + (t.dur > 0 ? t.dur : 30), title: t.title, done: isDone(t) });
  }
  for (const x of sessions().filter((s) => s.d === day && s.at)) {
    const m = hmMin(x.at); if (m == null) continue;
    timed.push({ kind: "session", c: actColor(x.act), from: m, to: m + Math.max(15, x.min || 0), title: actIcon(x.act) + " " + actName(x.act) + (x.note ? " · " + x.note : ""), done: true });
  }
  timed.sort((a, b) => a.from - b.from);
  // side by side when they overlap
  let i = 0;
  while (i < timed.length) {
    let j = i, end = timed[i].to; const lanesEnd = [];
    while (j < timed.length && (j === i || timed[j].from < end)) {
      const s = timed[j]; let lane = lanesEnd.findIndex((e) => e <= s.from); if (lane < 0) { lane = lanesEnd.length; lanesEnd.push(0); }
      lanesEnd[lane] = s.to; s.lane = lane; end = Math.max(end, s.to); j++;
    }
    for (let k = i; k < j; k++) timed[k].lanes = lanesEnd.length;
    i = j;
  }
  return [timed, allDay];
}
function timelineView() {
  const day = UI.tlDay || today();
  const ds = hmMin(setting("dayStart", "08:00")) ?? 480, de = hmMin(setting("dayEnd", "22:00")) ?? 1320;
  const [timed, allDay] = daySlots(day);
  const from = Math.min(ds, ...timed.map((s) => s.from)), to = Math.max(de, ...timed.map((s) => s.to));
  const h0 = Math.floor(from / 60), h1 = Math.ceil(to / 60); const PX = 1.1;
  let hours = ""; for (let x = h0; x <= h1; x++) hours += `<div class="hr" style="top:${(x * 60 - h0 * 60) * PX}px"><span>${pad(x % 24)}:00</span></div>`;
  const nm = hmMin(nowHM());
  const blocks = timed.map((s) => `<div class="blk ${s.done ? "dn" : ""}" style="top:${(s.from - h0 * 60) * PX}px;height:${Math.max(18, (s.to - s.from) * PX - 2)}px;left:calc(56px + (100% - 60px) * ${s.lane / s.lanes});width:calc((100% - 60px) / ${s.lanes} - 4px);border-color:${s.c};background:${s.c}26"
      ${s.kind === "task" ? `data-a="openTask" data-id="${s.t.id}"` : ""}><b>${hhmm(s.from)}</b> ${h(s.title)}</div>`).join("");
  const nowLine = day === today() && nm >= h0 * 60 && nm <= h1 * 60 ? `<div class="nowline" style="top:${(nm - h0 * 60) * PX}px"></div>` : "";
  return `<div class="line" style="display:flex;align-items:center;gap:8px"><button class="ghost" data-a="tlDay" data-by="-1">‹</button><h2 style="flex:1;text-align:center;margin:0">${dayLabel(day)}</h2><button class="ghost" data-a="tlDay" data-by="1">›</button>
    ${day !== today() ? '<button class="ghost gold" data-a="tlDay" data-by="0">Today</button>' : ""}</div>
    <div class="small muted" style="margin:6px 0">My day: <input type="time" id="dayStart" value="${h(setting("dayStart", "08:00"))}" data-change="dayStart"> to <input type="time" id="dayEnd" value="${h(setting("dayEnd", "22:00"))}" data-change="dayEnd"></div>
    ${allDay.length ? `<div class="kicker">Any time</div><div class="card sec">${allDay.map((s) => taskRow(s.t, { showDue: false })).join("")}</div>` : ""}
    <div class="card pad"><div class="tl" style="height:${(h1 - h0) * 60 * PX + 10}px">${hours}${blocks}${nowLine}</div></div>
    <div class="card sec" style="margin-top:10px">${addBox("Add a task on " + dayLabel(day), day, "inbox")}</div>`;
}

// ---------------------------------------------------------------- ideas
function ideasView() {
  const folders = ideaFolders(); const open = UI.folder && isIdeaFolder(UI.folder) ? UI.folder : null;
  if (!open) {
    const target = folders[0];
    return `<div class="muted" style="margin-bottom:8px">Ideas with no date yet. They stay here, out of your day, until you plan them.</div>
      <div class="card sec"><div class="add"><input type="text" id="ideaQuick" placeholder="${target ? "Write an idea (goes to " + h(target.name) + ")" : "Write an idea"} (Enter)" data-enter="ideaQuick"></div></div>
      <div class="folders">${folders.map((f) => { const it = ideasIn(f.id); const c = listColor(f.id); return `<div class="folder" style="border-color:${c}88" data-a="folder" data-id="${f.id}">
        <div class="line" style="display:flex;align-items:center"><span class="bigicon" style="background:${c}33">${listIcon(f.id)}</span><span style="flex:1"></span><b style="color:${c};font:bold 20px var(--serif)">${it.length}</b></div>
        <b>${h(f.name)}</b><div class="meta">${it[0] ? h(it[0].title) : "Empty"}</div></div>`; }).join("")}</div>
      <div class="kicker" style="margin-top:14px">📁 ${folders.length ? "Add a folder" : "Start with a folder"}</div><div class="card pad">
      ${STARTER_FOLDERS.filter(([, n]) => !folders.some((f) => f.name === n)).map(([i, n]) => pill(i + " " + n, false, `data-a="folderStarter" data-i="${i}" data-n="${h(n)}"`)).join("")}${pill("+ My own folder…", false, 'data-a="folderNew"')}</div>`;
  }
  const items = ideasIn(open); const waiting = items.filter((x) => !x.due), planned = items.filter((x) => x.due);
  return `<div class="line" style="display:flex;align-items:center;gap:10px;margin-bottom:8px"><button class="ghost" data-a="folder" data-id="">←</button><span class="bigicon" style="background:${listColor(open)}33">${listIcon(open)}</span>
      <h2 style="flex:1;margin:0">${h(listName(open))}</h2><button class="x" data-a="listEdit" data-id="${open}">✎</button></div>
    <div class="card sec">${addBox("Write an idea", "", open)}</div>
    <div class="kicker">Waiting · ${waiting.length}</div><div class="card sec">${waiting.map((x) => taskRow(x, { showList: false })).join("") || '<div class="empty">Nothing here yet. Write it down before it is gone.</div>'}</div>
    ${planned.length ? `<div class="kicker">Planned · ${planned.length}</div><div class="card sec">${planned.map((x) => taskRow(x, { showList: false })).join("")}</div>` : ""}
    <div class="muted small">Open an idea to add steps and notes. "Plan it" gives it a day, and it shows up in Today.</div>`;
}

// ---------------------------------------------------------------- the task panel
function taskDetail(t) {
  const ss = subs(t); const mins = minutesOnTask(t.id); const pl = plansForTask(t.id);
  return `<div class="card pad form">
    <div class="line"><button class="check ${isDone(t) ? "on" : ""}" style="border-color:${prioColor(t)}" data-a="toggle" data-id="${t.id}">${isDone(t) ? "✓" : ""}</button>
      <input type="text" id="t_title" value="${h(t.title)}" style="flex:1;font:600 18px var(--serif)" data-change="tfield" data-f="title"><button class="x" data-a="closeTask" title="Close">✕</button></div>
    ${!t.due && !isDone(t) ? `<div class="line"><span class="muted small">No date yet.</span><button class="ghost gold" data-a="due" data-d="0">📅 Plan it: today</button><button class="ghost" data-a="due" data-d="1">tomorrow</button></div>` : ""}
    <div class="line"><label>Date</label><input type="date" id="t_due" value="${h(t.due || "")}" data-change="tfield" data-f="due">
      <button class="ghost" data-a="due" data-d="0">Today</button><button class="ghost" data-a="due" data-d="1">Tomorrow</button><button class="ghost" data-a="due" data-d="7">Next week</button>${t.due ? '<button class="x" data-a="due" data-d="none" title="No date">✕</button>' : ""}</div>
    <div class="line"><label>Time</label><input type="time" id="t_time" value="${h(t.time || "")}" data-change="tfield" data-f="time">
      ${t.time ? `<label style="min-width:auto">for</label><input type="number" id="t_dur" min="0" step="5" style="width:76px" value="${t.dur || ""}" placeholder="min" data-change="tfield" data-f="dur">
      <select id="t_rem" data-change="tfield" data-f="remind">${REMINDS.map(([v, n]) => opt(v, t.remind || 0, "🔔 " + n)).join("")}</select><button class="x" data-a="noTime" title="Remove the time">✕</button>` : ""}</div>
    <div class="line"><label>Priority</label><span>${PRIO_NAMES.map((p, i) => pill(p, (t.prio || 0) === i, `data-a="tprio" data-v="${i}"`, i ? PRIO_COLORS[i] : null)).join("")}</span></div>
    <div class="line"><label>Repeat</label><select id="t_rep" data-change="tfield" data-f="repeat">${REPEATS.map(([v, n]) => opt(v, t.repeat || "", n)).join("")}</select>
      <label style="min-width:auto">List</label><select id="t_list" data-change="tfield" data-f="list">${lists().map((l) => opt(l.id, t.list, (l.idea ? "💡 " : "") + l.name)).join("")}</select></div>
    <div class="line"><label>Counts for</label><select id="t_act" data-change="tfield" data-f="act">${opt("", t.act || "", "—")}${acts().map((a) => opt(a.id, t.act || "", actIcon(a.id) + " " + a.name)).join("")}</select>
      ${mins ? `<span class="small muted">⏱ ${fmtMin(mins)} spent</span>` : ""}</div>
    <div><div class="kicker">☑ Steps ${ss.length ? ss.filter((x) => x.done).length + "/" + ss.length : ""}</div>
      ${ss.map((x, i) => `<div class="step"><button class="check sq ${x.done ? "on" : ""}" data-a="sub" data-id="${t.id}" data-s="${x.id}">${x.done ? "✓" : ""}</button>
        <input type="text" id="st_${x.id}" value="${h(x.t)}" data-change="subText" data-id="${t.id}" data-s="${x.id}" class="${x.done ? "muted strike" : ""}">
        <button class="x" data-a="subMove" data-id="${t.id}" data-s="${x.id}" data-by="-1" ${i === 0 ? "disabled" : ""} title="Up">↑</button>
        <button class="x" data-a="subMove" data-id="${t.id}" data-s="${x.id}" data-by="1" ${i === ss.length - 1 ? "disabled" : ""} title="Down">↓</button>
        <button class="x" data-a="subTask" data-id="${t.id}" data-s="${x.id}" title="Make it a task of its own">⇱</button>
        <button class="x" data-a="subDel" data-id="${t.id}" data-s="${x.id}" title="Delete">×</button></div>`).join("")}
      <input type="text" id="addStep" placeholder="+ Add a step (Enter)" style="width:100%" data-enter="addStep" data-id="${t.id}"></div>
    <div><div class="kicker">💰 Money</div><div>${pl.map((p) => pill(planIcon(p) + " " + (planSign(p) > 0 ? "+" : "−") + fmtMoney(planLeft(p)) + " " + (p.cur || mainCur()), false, `data-a="planEdit" data-id="${p.id}"`)).join("")}${pill("+ Money", false, `data-a="planNew" data-task="${t.id}"`)}</div></div>
    <div><div class="kicker">📝 Note</div><textarea id="t_note" data-change="tfield" data-f="note">${h(t.note || "")}</textarea></div>
    <div class="btns"><button class="btn" data-a="toggle" data-id="${t.id}">${isDone(t) ? "Not done" : "✓ Done"}</button>
      ${isDone(t) ? "" : `<button class="ghost gold" data-a="focus" data-id="${t.id}">▶ Focus</button><button class="ghost" data-a="later" data-id="${t.id}">Later → tomorrow</button>`}
      <button class="ghost red" data-a="delTask" data-id="${t.id}">Delete</button></div>
    <div class="small muted">Created ${t.created ? new Date(t.created).toLocaleDateString("en-GB") : ""}${t.done ? " · done " + dayLabel(t.done) : ""}</div></div>`;
}

// ---------------------------------------------------------------- the list / folder editor
MODAL.list = (m) => {
  const d = m.d; const isNew = !m.id; const c = listColorOf(d.color || 0);
  const title = d.idea ? (isNew ? "New idea folder" : "Edit folder") : isNew ? "New list" : "Edit list";
  return dlg(title, `<div class="line" style="display:flex;gap:10px;align-items:center"><span class="bigicon" style="background:${c}33">${h(d.icon)}</span>
      <input type="text" data-m="name" value="${h(d.name)}" placeholder="List name" style="flex:1;font:600 18px var(--serif)" autofocus data-enter="listSave"></div>
    <div class="kicker" style="margin-top:12px">🎨 Colour</div>${colorPick(d.color || 0)}<div class="kicker">✨ Icon</div>${iconPick(LIST_ICONS, d.icon)}`,
    `${!isNew && m.id !== "inbox" ? '<button class="ghost red" data-a="listDel">Delete</button>' : ""}<span style="flex:1"></span><button class="ghost" data-a="closeModal">Cancel</button><button class="btn" data-a="listSave">Save</button>`);
};

Object.assign(A, {
  tview(el) { UI.tview = el.dataset.v; UI.sel = []; if (UI.tview !== "ideas") UI.folder = null; render(); if (UI.tview === "search") setTimeout(() => $("#q") && $("#q").focus(), 0); },
  closeTask() { UI.task = null; render(); },
  newTaskFull(el) { const t = addTask("New task", el.dataset.list || "inbox", el.dataset.due || ""); UI.task = t.id; commit().then(() => { const i = $("#t_title"); if (i) { i.focus(); i.select(); } }); },
  due(el) { const t = find("tasks", UI.task); if (!t) return; const v = el.dataset.d; t.due = v === "none" ? "" : addDays(today(), +v); if (!t.due) { t.time = ""; t.repeat = ""; } commit(); },
  noTime() { const t = find("tasks", UI.task); if (t) { t.time = ""; t.remind = 0; t.dur = 0; commit(); } },
  tprio(el) { const t = find("tasks", UI.task); if (t) { t.prio = +el.dataset.v; commit(); } },
  subDel(el) { const t = find("tasks", el.dataset.id); if (t) { t.sub = subs(t).filter((y) => y.id !== el.dataset.s); commit(); } },
  subMove(el) { const t = find("tasks", el.dataset.id); if (!t) return; const l = subs(t); const i = l.findIndex((y) => y.id === el.dataset.s); const j = i + +el.dataset.by; if (i < 0 || j < 0 || j >= l.length) return; [l[i], l[j]] = [l[j], l[i]]; commit(); },
  subTask(el) { subToTask(el.dataset.id, el.dataset.s); toast("Step is now a task"); commit(); },
  async delTask(el) { if (!await ask("Delete this task? It goes from the phone too.")) return; removeId("tasks", el.dataset.id); UI.task = null; commit(); },
  async clearHist(el) {
    const all = el.dataset.v === "all";
    if (!await ask((all ? "Every finished task is deleted." : "Finished tasks from more than 30 days ago are deleted.") + " Your open tasks, time and money stay. This cannot be undone.")) return;
    const n = clearHistory(all ? null : addDays(today(), -30)); toast(n ? n + " removed from history" : "Nothing that old"); commit();
  },
  async bulk(el) {
    const v = el.dataset.v; const ids = UI.sel.slice(); const ts = ids.map((i) => find("tasks", i)).filter(Boolean);
    if (v === "none") { UI.sel = []; render(); return; }
    if (v === "all") { UI.sel = Array.from(new Set(UI.sel.concat(visibleIds()))); render(); return; }
    if (v === "done") { const open = ts.filter((x) => !isDone(x)); open.forEach((x) => toggleTask(x.id)); toast(open.length + " done ✓"); }
    else if (v === "today" || v === "tomorrow") { const d = addDays(today(), v === "today" ? 0 : 1); ts.forEach((x) => (x.due = d)); toast(ts.length + " moved to " + dayLabel(d)); }
    else if (v === "nodate") { ts.forEach((x) => { x.due = ""; x.time = ""; x.repeat = ""; }); toast(ts.length + " moved to no date"); }
    else if (v === "delete") { if (!await ask("Delete " + ts.length + " tasks? This cannot be undone.")) return; R.tasks = tasks().filter((x) => !ids.includes(x.id)); toast(ts.length + " deleted"); if (ids.includes(UI.task)) UI.task = null; }
    UI.sel = []; commit();
  },
  calDay(el) { UI.calDay = el.dataset.v; render(); },
  calMonth(el) { const ym = UI.calMonth || today().slice(0, 7); UI.calMonth = addMonths(ym + "-01", +el.dataset.by).slice(0, 7); render(); },
  calToday() { UI.calMonth = ""; UI.calDay = ""; render(); },
  tlDay(el) { UI.tlDay = el.dataset.by === "0" ? today() : addDays(UI.tlDay || today(), +el.dataset.by); render(); },
  folder(el) { UI.folder = el.dataset.id || null; render(); },
  folderStarter(el) { UI.folder = addList(el.dataset.n, el.dataset.i, 0, true); commit(); },
  folderNew() { openModal("list", { d: { name: "", icon: "💡", color: 0, idea: true } }); },
  listNew() { openModal("list", { d: { name: "", icon: "📁", color: 0, idea: false } }); },
  listEdit(el) { const l = find("lists", el.dataset.id); if (l) openModal("list", { id: l.id, d: { name: l.name, icon: listIcon(l.id), color: l.color || 0, idea: !!l.idea } }); },
  listSave() {
    const m = UI.modal; const d = m.d; const name = (d.name || "").trim(); if (!name) { toast("Give it a name"); return; }
    const l = m.id && find("lists", m.id);
    if (l) Object.assign(l, { name, icon: d.icon, color: d.color });
    else { const id = addList(name, d.icon, d.color, !!d.idea); if (d.idea) UI.folder = id; else UI.tview = "list:" + id; }
    UI.modal = null; commit();
  },
  async listDel() {
    const m = UI.modal; if (!await ask("Delete this list? Its tasks move to the Inbox.")) return;
    deleteList(m.id); if (UI.tview === "list:" + m.id) UI.tview = "today"; if (UI.folder === m.id) UI.folder = null; UI.modal = null; commit();
  },
});
Object.assign(ENTER, {
  addTask(el) {
    const v = el.value.trim(); if (!v) return;
    const t = addTask(v, el.dataset.list || "inbox", el.dataset.due || "");
    el.value = ""; if (UI.view === "tasks" && !["timeline", "calendar", "ideas"].includes(UI.tview)) UI.task = t.id; commit();
  },
  ideaQuick(el) {
    const v = el.value.trim(); if (!v) return;
    const f = (ideaFolders()[0] || {}).id || addList("Ideas", "💡", 0, true);
    addTask(v, f, ""); el.value = ""; toast("Saved in " + listName(f)); commit();
  },
  listSave() { readModal(); A.listSave(); },
});
Object.assign(CHANGE, {
  tfield(el) {
    const t = find("tasks", UI.task); if (!t) return;
    const f = el.dataset.f; let v = el.value;
    if (f === "dur") v = parseInt(v, 10) || 0; else if (f === "remind") v = +v; else if (f === "title") { v = v.trim(); if (!v) { render(); return; } }
    t[f] = v;
    if (f === "due" && !v) { t.time = ""; t.repeat = ""; }
    if (f === "time" && !v) { t.remind = 0; t.dur = 0; }
    commit();
  },
  subText(el) { const t = find("tasks", el.dataset.id); const x = t && subs(t).find((y) => y.id === el.dataset.s); if (x && el.value.trim()) { x.t = el.value.trim(); commit(); } },
  bulkDate(el) { if (!el.value) return; const ts = UI.sel.map((i) => find("tasks", i)).filter(Boolean); ts.forEach((x) => (x.due = el.value)); toast(ts.length + " moved to " + dayLabel(el.value)); UI.sel = []; commit(); },
  bulkList(el) { if (!el.value) return; const ts = UI.sel.map((i) => find("tasks", i)).filter(Boolean); ts.forEach((x) => (x.list = el.value)); toast(ts.length + " moved to " + listName(el.value)); UI.sel = []; commit(); },
  bulkPrio(el) { if (el.value === "") return; const ts = UI.sel.map((i) => find("tasks", i)).filter(Boolean); ts.forEach((x) => (x.prio = +el.value)); toast(ts.length + " set to " + PRIO_NAMES[+el.value]); UI.sel = []; commit(); },
  dayStart(el) { if (el.value) { setSetting("dayStart", el.value); commit(); } },
  dayEnd(el) { if (el.value) { setSetting("dayEnd", el.value); commit(); } },
});
document.addEventListener("input", (ev) => {
  const el = ev.target;
  if (el.dataset && el.dataset.input === "search") { UI.query = el.value; render(); }
});
