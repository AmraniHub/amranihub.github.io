"use strict";
// Today: the wealth card, the day in three numbers, late tasks, what to do now, later today, today's tasks, habits.

VIEW.today = () => {
  const td = today(); const tt = todayTasks(); const done = doneOn(td);
  const target = acts().reduce((n, a) => n + todayTarget(a.id), 0);
  const mc = mainCur(); const m = totals(txs().filter((t) => t.d === td))[mc];
  const net = m ? m[0] - m[1] : null;
  const late = lateTasks();
  const r = running();
  const nu = r ? null : nextUp();
  let s = `<div class="toprow"><div><div class="kicker">${new Date().toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" })}</div>
    <h1>Today</h1><div class="creed click" data-a="editCreed" title="Click to change">${h(creed())}</div></div>
    <div class="btns"><button class="ghost" data-a="goTimeline">🕘 My day</button></div></div>`;
  s += wealthCard();
  s += `<div class="tiles">
    <div class="tile" data-go="time"><div class="e">⏱</div><div class="v">${fmtMin(minutesToday())}</div><div class="l">${target ? "of " + fmtMin(target) + " planned" : "today"}</div></div>
    <div class="tile" data-go="tasks"><div class="e">✓</div><div class="v">${done}/${done + tt.length}</div><div class="l">tasks done</div></div>
    <div class="tile" data-go="money"><div class="e">💰</div><div class="v ${net == null ? "" : net >= 0 ? "green" : "red"}">${net == null ? "—" : (net >= 0 ? "+" : "−") + fmtMoney(Math.abs(net))}</div><div class="l">${mc} today</div></div>
  </div>`;
  if (late.length) s += `<div class="late"><span>${late.length} late from earlier days</span><button class="ghost gold" data-a="moveLate" data-d="0">→ Today</button><button class="ghost" data-a="moveLate" data-d="1">→ Tomorrow</button></div>`;
  s += r ? runningCard() : nowCard(nu);
  s += `<div class="grid cols2"><div>`;
  const nm = hmMin(nowHM());
  const laterT = tt.filter((t) => t.due === td && hmMin(t.time) != null && hmMin(t.time) > nm && t !== nu).sort((a, b) => hmMin(a.time) - hmMin(b.time)).slice(0, 3);
  if (laterT.length) s += `<div class="kicker">🕘 Later today</div><div class="card sec">${laterT.map((t) => `<div class="row click" data-a="openTask" data-id="${t.id}"><b class="gold" style="width:50px">${t.time}</b><div class="grow t">${h(t.title)}</div><span class="meta">in ${fmtMin(hmMin(t.time) - nm)}</span></div>`).join("")}
    <div class="row click" data-a="goTimeline"><span>🕘</span><div class="grow gold">See my whole day</div></div></div>`;
  s += `<div class="kicker">✅ Today's tasks · ${tt.length} left</div>
    <div class="card">${tt.map((t) => taskRow(t, { showDue: false })).join("") || '<div class="empty">Nothing left for today. Add what matters most.</div>'}
    <div class="add"><input type="text" id="addToday" placeholder="Add a task for today… (Enter)" data-enter="addToday"></div></div>`;
  const doneT = tasks().filter((t) => t.done === td);
  if (doneT.length) s += `<div class="kicker" style="margin-top:16px">✓ Completed today · ${doneT.length}</div><div class="card">${doneT.map((t) => taskRow(t)).join("")}</div>`;
  s += `</div><div>${habitsCard()}</div></div>`;
  return s;
};

function wealthCard() {
  const cur = mainCur(); const worth = netWorth(cur);
  const hidden = setting("hideWealth") === "1";
  const legacy = num(setting("legacy", "0"));
  const [inM, outM] = totals(monthTx(today().slice(0, 7)))[cur] || [0, 0];
  const change = inM - outM;
  const hist = holdingHistory(cur);
  let line = "";
  if (!hidden && hist.length > 1) {
    const lo = Math.min(...hist), hi = Math.max(...hist), span = hi - lo || 1, W = 600, H = 54;
    const pts = hist.map((v, i) => [(i * W) / (hist.length - 1), H - 4 - ((v - lo) / span) * (H - 8)]);
    const p = pts.map((q, i) => (i ? "L" : "M") + q[0].toFixed(1) + "," + q[1].toFixed(1)).join(" ");
    line = `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" class="wline"><defs><linearGradient id="wf" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#D4AF37" stop-opacity=".28"/><stop offset="1" stop-color="#D4AF37" stop-opacity="0"/></linearGradient></defs>
      <path d="${p} L${W},${H} L0,${H} Z" fill="url(#wf)"/><path d="${p}" fill="none" stroke="#F3DC9A" stroke-width="2.5" vector-effect="non-scaling-stroke"/></svg>`;
  }
  const f = legacy > 0 ? Math.max(0, Math.min(1, worth / legacy)) : 0;
  return `<div class="wealth"><div class="line" style="display:flex;align-items:center;gap:8px"><img src="/star.svg" style="width:18px">
      <b class="gold small" style="letter-spacing:2px;flex:1">YOUR WEALTH</b><button class="x" data-a="hideWealth" title="Hide the amounts">${hidden ? "🙈" : "👁"}</button></div>
    <div class="wv">${hidden ? "••••••" : fmtMoney(Math.round(worth))} ${cur}</div>
    ${hidden ? "" : `<div class="small ${change >= 0 ? "green" : "red"}">${change >= 0 ? "▲ +" : "▼ −"}${fmtMoney(Math.abs(change))} ${cur} this month</div>`}
    ${line}
    ${legacy > 0 ? `<div class="line" style="display:flex;margin-top:8px"><span class="muted small" style="flex:1;letter-spacing:1.3px">GENERATIONAL GOAL</span>
      <span class="gold2 small click" data-a="setLegacy">${hidden ? Math.floor(f * 100) + "%" : (f * 100).toFixed(1) + "% of " + fmtMoney(legacy)}</span></div>
      <div class="bar" style="height:8px"><i style="width:${Math.max(1, f * 100)}%;background:linear-gradient(90deg,#D4AF37,#F3DC9A)"></i></div>` :
      `<button class="ghost gold small" style="margin-top:8px" data-a="setLegacy">＋ Set your generational goal</button>`}</div>`;
}

function nowCard(t) {
  if (!t) return `<div class="now"><div class="lab">NOW</div><div class="ti">Nothing planned now.</div><div class="muted">Add a task below, or start a timer in Time.</div></div>`;
  const nx = nextSub(t);
  const meta = [listIcon(t.list) + " " + h(listName(t.list)), t.due !== today() ? '<span class="red">' + dayLabel(t.due) + "</span>" : "", t.time ? "🕘 " + t.time : ""].filter(Boolean).join(" · ");
  const pl = plansForTask(t.id);
  return `<div class="now"><div class="lab">NOW</div><div class="ti">${h(t.title)}</div><div class="muted">${meta}</div>
    ${nx ? `<div style="margin:10px 0">Next step: <b class="gold2">${h(nx.t)}</b> <button class="ghost" data-a="sub" data-id="${t.id}" data-s="${nx.id}">✓ step</button></div>` : ""}
    ${pl.length ? `<div class="small" style="margin-top:6px">${pl.map((p) => `${planIcon(p)} ${planSign(p) > 0 ? "+" : "−"}${fmtMoney(planLeft(p))} ${p.cur || mainCur()}`).join("  ·  ")}</div>` : ""}
    <div class="btns" style="margin-top:12px"><button class="btn" data-a="toggle" data-id="${t.id}">✓ Done</button>
    <button class="ghost gold" data-a="focus" data-id="${t.id}">▶ Focus</button>
    <button class="ghost" data-a="later" data-id="${t.id}">Later → tomorrow</button>
    <button class="ghost" data-a="skipNow" data-id="${t.id}">Not now</button>
    <button class="ghost" data-a="openTask" data-id="${t.id}">Open</button></div></div>`;
}

function habitsCard() {
  const hb = habits(); const td = today(); const done = hb.filter((x) => habitDone(x.id)).length;
  const week = [6, 5, 4, 3, 2, 1, 0].map((i) => addDays(td, -i));
  return `<div class="kicker">🔥 My daily habits ${hb.length ? "· " + done + " of " + hb.length : ""}</div><div class="card">
    ${hb.length ? "" : '<div class="empty">Your list, your rules: gym, water, reading, prayer, skincare… Add the first one.</div>'}
    ${hb.map((x) => {
      const c = listColorOf(x.color || 0); const on = habitDone(x.id); const st = habitStreak(x.id);
      return `<div class="row" style="flex-wrap:wrap"><button class="check ${on ? "on" : ""}" style="border-color:${c};${on ? "background:" + c : ""};width:28px;height:28px" data-a="habit" data-id="${x.id}" data-d="${td}">${on ? "✓" : ""}</button>
        <div class="grow t click ${on ? "muted strike" : ""}" data-a="habitEdit" data-id="${x.id}">${h(x.icon || "✨")} ${h(x.name)}</div>
        ${st ? `<b class="amber small">🔥 ${st}</b>` : ""}<button class="x" data-a="habitEdit" data-id="${x.id}">✎</button>
        <div class="week">${week.map((d) => `<button class="wd ${habitDone(x.id, d) ? "on" : ""} ${d === td ? "today" : ""}" style="${habitDone(x.id, d) ? "background:" + c : ""}" data-a="habit" data-id="${x.id}" data-d="${d}" title="${dayLabel(d)}">${dow1(d)}</button>`).join("")}</div></div>`;
    }).join("")}
    <div class="row"><button class="ghost gold" data-a="habitNew">➕ New habit</button>${hb.length ? '<button class="ghost" data-a="habitsAll">📊 Progress</button>' : ""}</div></div>`;
}

Object.assign(A, {
  goTimeline() { UI.view = "tasks"; UI.tview = "timeline"; UI.tlDay = today(); render(); },
  hideWealth() { setSetting("hideWealth", setting("hideWealth") === "1" ? "0" : "1"); commit(); },
  setLegacy() { openModal("amount", { title: "The wealth you are building for your family", cur: mainCur(), then: "legacy", d: { v: setting("legacy", "") } }); },
  skipNow(el) { (UI.skipped || (UI.skipped = [])).push(el.dataset.id); render(); },
  habit(el) { toggleHabitOn(el.dataset.id, el.dataset.d || today()); commit(); },
  habitNew() { openModal("habit", { d: { name: "", icon: "✨", color: 0 }, ym: today().slice(0, 7) }); },
  habitEdit(el) { const x = find("habits", el.dataset.id); if (x) openModal("habit", { id: x.id, d: { name: x.name, icon: x.icon || "✨", color: x.color || 0 }, ym: today().slice(0, 7) }); },
  habitsAll() { openModal("habits"); },
  habitSave() {
    const m = UI.modal; const d = m.d; const name = (d.name || "").trim(); if (!name) { toast("Give the habit a name"); return; }
    const x = m.id && find("habits", m.id);
    if (x) Object.assign(x, { name, icon: d.icon, color: d.color }); else habits().push({ id: newId(), name, icon: d.icon, color: d.color });
    UI.modal = null; commit();
  },
  async habitDel() { if (!await ask("Delete this habit and its history?")) return; deleteHabit(UI.modal.id); UI.modal = null; commit(); },
  habitMonth(el) { UI.modal.ym = addMonths(UI.modal.ym + "-01", +el.dataset.by).slice(0, 7); render(); },
});
// Not now: skip the suggestion until the window reloads (as on the phone, until the app restarts).
const _nextUp = nextUp;
nextUp = function () { const sk = UI.skipped || []; const n = _nextUp(); if (n && !sk.includes(n.id)) return n; return todayTasks().find((t) => !sk.includes(t.id)) || null; }; // eslint-disable-line no-global-assign
ENTER.addToday = (el) => { const v = el.value.trim(); if (!v) return; addTask(v, "inbox", today()); el.value = ""; commit(); };

MODAL.habit = (m) => {
  const d = m.d; const isNew = !m.id; const c = listColorOf(d.color || 0);
  let cal = "";
  if (!isNew) {
    const ym = m.ym; const lead = (parseD(ym + "-01").getDay() + 6) % 7; const n = monthLen(ym); const td = today();
    let cells = ""; for (let i = 0; i < lead; i++) cells += "<span></span>";
    for (let i = 1; i <= n; i++) {
      const day = ym + "-" + pad(i); const ok = habitDone(m.id, day); const fut = day > td;
      cells += `<button class="cd ${ok ? "on" : ""} ${day === td ? "today" : ""}" style="${ok ? "background:" + c : ""}" ${fut ? "disabled" : `data-a="habit" data-id="${m.id}" data-d="${day}"`}>${i}</button>`;
    }
    cal = `<div class="stats3"><div><b>${habitStreak(m.id)}</b><span>Streak</span></div><div><b>${habitBest(m.id)}</b><span>Best streak</span></div><div><b>${Math.round(habitRate(m.id, 30) * 100 / 30)}%</b><span>Last 30 days</span></div></div>
      <div class="kicker" style="margin-top:12px">🗓 Tap a day to tick or untick it</div>
      <div class="line" style="display:flex;align-items:center"><button class="ghost" data-a="habitMonth" data-by="-1">‹</button><b style="flex:1;text-align:center">${monthName(ym)}</b>
        <button class="ghost" data-a="habitMonth" data-by="1" ${ym >= td.slice(0, 7) ? "disabled" : ""}>›</button></div>
      <div class="calgrid">${DOW.map((x) => `<span class="muted small">${x}</span>`).join("")}${cells}</div>`;
  }
  return dlg(isNew ? "New daily habit" : "Edit habit", `<div class="line" style="display:flex;gap:10px;align-items:center"><span class="bigicon" style="background:${c}33">${h(d.icon)}</span>
      <input type="text" data-m="name" value="${h(d.name)}" placeholder="e.g. Drink 2 L of water" style="flex:1;font:600 18px var(--serif)" autofocus></div>
    ${cal}<div class="kicker" style="margin-top:12px">🎨 Colour</div>${colorPick(d.color || 0)}<div class="kicker">✨ Icon</div>${iconPick(HABIT_ICONS, d.icon)}`,
    `${isNew ? "" : '<button class="ghost red" data-a="habitDel">Delete</button>'}<span style="flex:1"></span><button class="ghost" data-a="closeModal">Cancel</button><button class="btn" data-a="habitSave">Save</button>`);
};
MODAL.habits = () => {
  const hb = habits(); const td = today();
  const rate = hb.length ? Math.round(hb.reduce((n, x) => n + habitRate(x.id, 7), 0) * 100 / (hb.length * 7)) : 0;
  return dlg("Habits", `<div class="stats3"><div><b>${hb.filter((x) => habitDone(x.id)).length}/${hb.length}</b><span>Today</span></div><div><b>${rate}%</b><span>Last 7 days</span></div>
    <div><b>${Math.max(0, ...hb.map((x) => habitBest(x.id)))}</b><span>Best streak</span></div></div>
    ${hb.map((x) => { const c = listColorOf(x.color || 0); const days = []; for (let i = 34; i >= 0; i--) days.push(addDays(td, -i));
      return `<div class="card pad" style="margin-top:10px"><div class="line click" style="display:flex;gap:10px;align-items:center" data-a="habitEdit" data-id="${x.id}"><span class="bigicon" style="background:${c}33">${h(x.icon || "✨")}</span>
        <div style="flex:1"><b>${h(x.name)}</b><div class="meta">🔥 ${habitStreak(x.id)} · best ${habitBest(x.id)} · ${habitRate(x.id, 30)}/30 days</div></div><span class="muted">›</span></div>
        <div class="sq35">${days.map((d) => `<i style="${habitDone(x.id, d) ? "background:" + c : ""}" title="${d}"></i>`).join("")}</div></div>`; }).join("") || '<div class="empty">No habits yet.</div>'}`);
};

// A dialog with one amount (generational goal, put into a goal, a debt payment...).
MODAL.amount = (m) => dlg(m.title, `<div class="line" style="display:flex;gap:8px;align-items:center"><input type="text" class="big" data-m="v" value="${h(m.d.v || "")}" placeholder="0" style="flex:1" autofocus data-enter="amountSave"><b class="muted">${h(m.cur || "")}</b></div>
  <div id="amt_why" class="red small"></div>`,
  `<button class="ghost" data-a="closeModal">Cancel</button><button class="btn" data-a="amountSave">Save</button>`);
A.amountSave = () => {
  const m = UI.modal; const v = num(m.d.v);
  if (!(v > 0)) { const w = $("#amt_why"); if (w) w.textContent = "Type the amount first"; return; }
  if (m.then === "legacy") setSetting("legacy", String(v));
  else if (m.then === "goal") moveGoal(m.id, m.sign * v);
  else if (m.then === "plan") { completePlan(m.id, v); toast("Written in Money ✓"); }
  UI.modal = null; commit();
};
ENTER.amountSave = () => { readModal(); A.amountSave(); };
