"use strict";
// Settings and the phone link.

VIEW.settings = () => {
  const pairs = S.pairs || []; const pg = S.pairing;
  let s = `<h1>Settings & phone</h1><div class="creed">Same Wi-Fi, no account, no cloud. Tasks, time and money stay the same on both.</div>`;
  if (S.paired_now) s += `<div class="now"><div class="lab">LINKED ✓</div><div class="ti">${h(S.paired_now)} is linked</div><div class="muted">Its data is arriving. Changes on either one now show on the other within seconds while the phone app is open.</div></div>`;
  if (pg) {
    s += `<div class="now"><div class="lab">LINK A PHONE · ${Math.floor(pg.left / 60)}:${pad(pg.left % 60)} LEFT</div>
      <div style="display:flex;gap:28px;align-items:center;flex-wrap:wrap;margin-top:10px"><div class="qr">${pg.qr || ""}</div>
        <div><div class="muted">On the phone: <b>⚙ Settings → Laptop</b>, then type</div><div class="code" style="margin:10px 0">${h(pg.code)}</div>
        <div class="muted small">or tap "take a photo of the QR code" and photograph this one.<br>The phone must be on the same Wi-Fi as this laptop (${h(S.ip)}).</div>
        <div class="btns" style="margin-top:14px"><button class="ghost" data-a="pairStop">Cancel</button></div></div></div></div>`;
  }
  s += `<div class="grid cols2"><div><div class="kicker">📱 Linked phones</div><div class="card">${pairs.map((p) => `<div class="row"><span>📱</span><div class="grow"><div class="t">${h(p.dev || "Phone")}</div>
      <div class="meta">linked ${p.since ? new Date(p.since).toLocaleDateString("en-GB") : ""} · last sync ${ago(p.seen)}</div></div>
      <button class="ghost red" data-a="unpair" data-id="${p.pair}">Unlink</button></div>`).join("") || '<div class="empty">No phone linked yet.</div>'}
    ${pg ? "" : `<div class="add"><button class="btn" data-a="pairStart">📱 Link a phone</button></div>`}</div>
    <div class="muted small" style="margin:6px 4px">The phone syncs while Qarun is open on it, every few seconds. Changes made while apart wait on each side and merge when they meet again; for each item the newest change wins. A past day's time never changes.</div>`;
  const rc = Object.keys(records(R)).filter((k) => !k.startsWith("set/")).length;
  s += `<div class="kicker" style="margin-top:18px">💾 Data on this laptop</div><div class="card">
    <div class="row"><div class="grow">${tasks().length} tasks, ${sessions().length} time entries, ${txs().length} money entries, ${habits().length} habits</div></div>
    <div class="row"><div class="grow small muted">Kept in ${h(S.data)}, with a copy each day and before each first link in its backups folder.</div><button class="ghost" data-a="backup">Back up now</button></div>
    ${!rc ? `<div class="row"><div class="grow small muted">No phone? Start with the same lists, activities and categories a new phone gets.</div><button class="ghost" data-a="seed">Start without a phone</button></div>` : ""}
    <div class="row"><div class="grow small muted">Qarun keeps syncing in the background while this laptop is on, even with this window closed.</div><button class="ghost red" data-a="quit">Quit Qarun</button></div></div></div>`;
  s += `<div><div class="kicker">⚙ General (shared with the phone)</div><div class="card">
    <div class="row click" data-a="editCreed"><span>✍️</span><div class="grow"><div>Your line</div><div class="meta">${h(creed())}</div></div><span class="muted">✎</span></div>
    <div class="row click" data-a="setLegacy"><span>💎</span><div class="grow"><div>Generational goal</div><div class="meta">${num(setting("legacy", "0")) > 0 ? fmtMoney(num(setting("legacy", "0"))) + " " + mainCur() : "Not set"}</div></div><span class="muted">✎</span></div>
    <div class="row"><span>🕘</span><div class="grow">My day</div><input type="time" id="s_ds" value="${h(setting("dayStart", "08:00"))}" data-change="dayStart"> – <input type="time" id="s_de" value="${h(setting("dayEnd", "22:00"))}" data-change="dayEnd"></div>
    <div class="row"><span>🎯</span><div class="grow">Focus length (from a task)</div><select id="s_fd" data-change="focusDur">${[15, 25, 45, 60, 90, 0].map((x) => opt(x, setting("focusDur", "25"), x ? fmtMin(x) : "No limit")).join("")}</select></div></div>
    <div class="kicker" style="margin-top:18px">💻 This laptop only</div><div class="card">
    <div class="row"><span>👁</span><div class="grow">Hide amounts on the wealth card</div><input type="checkbox" data-a="hideWealth" ${setting("hideWealth") === "1" ? "checked" : ""}></div>
    <div class="row"><span>🔔</span><div class="grow"><div>Task reminders</div><div class="meta">Ring here while this window is open${window.Notification ? (Notification.permission === "granted" ? " · notifications allowed" : " · allow notifications for a pop-up") : ""}</div></div>
      ${window.Notification && Notification.permission !== "granted" ? '<button class="ghost gold" data-a="askNotify">Allow</button>' : ""}</div></div></div></div>`;
  return s;
};

Object.assign(A, {
  async pairStart() { adopt(await api("/ui/pair/start", {})); },
  async pairStop() { adopt(await api("/ui/pair/stop", {})); },
  async unpair(el) { if (!await ask("Unlink this phone? Both keep their data.")) return; adopt(await api("/ui/unpair", { pair: el.dataset.id })); },
  async backup() { const r = await api("/ui/backup", {}); toast(r.file ? "Backup saved ✓" : "Nothing to back up yet"); },
  async quit() { if (!await ask("Quit Qarun on this laptop? The phone cannot sync until you open it again.")) return; try { await api("/ui/quit", {}); } catch (e) { } document.body.innerHTML = '<div class="empty">Qarun is closed. Open it again from the desktop icon.</div>'; },
  async askNotify() { try { await Notification.requestPermission(); } catch (e) { } render(); },
});
CHANGE.focusDur = (el) => { setSetting("focusDur", el.value); commit(); };

render.ready = true;
watch();
