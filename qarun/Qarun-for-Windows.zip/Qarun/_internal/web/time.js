"use strict";
// Time: what a tap starts, the activity tiles, week goals and pace, this week's chart, the history, editors.

const MODES = [0, 25, 45, 60, 90];
const modeName = (m) => (m === 0 ? "⏱ Stopwatch" : "🎯 " + m + " min");

VIEW.time = () => {
  const r = running(); const plan = acts().reduce((n, a) => n + todayTarget(a.id), 0);
  const mode = +setting("mode", "0") || 0;
  let s = `<div class="toprow"><div><h1>Time</h1><div class="creed">${plan ? `Today ${fmtMin(minutesToday())} of ${fmtMin(plan)} planned · week ${fmtMin(minutesWeek())}` : `Today ${fmtMin(minutesToday())} · this week ${fmtMin(minutesWeek())}`}</div></div>
    <div class="btns"><button class="ghost gold" data-a="sessNew">✍️ Add time by hand</button><button class="ghost gold" data-a="actNew">➕ New activity</button></div></div>`;
  if (r) s += runningCard();
  if (!acts().length) return s + `<div class="card pad"><p class="muted">Add what you want to spend time on: work, a language, a skill, sport.</p><button class="btn" data-a="actNew">➕ New activity</button></div>`;
  s += `<div class="line" style="display:flex;gap:8px;align-items:center;margin-bottom:10px"><span class="muted">A click starts:</span>${MODES.map((m) => pill(modeName(m), mode === m, `data-a="mode" data-v="${m}"`)).join("")}</div>`;
  s += `<div class="acts">${acts().map((a) => actTile(a)).join("")}</div><div class="muted small" style="margin:-8px 0 16px">Click a tile to start or stop it. ✎ edits it (name, goal, colour, icon, steps).</div>`;
  s += `<div class="grid cols2"><div>${weekPace()}${weekChart()}</div><div>${history()}</div></div>`;
  return s;
};

function actTile(a) {
  const r = running(); const isRun = r && r.act === a.id; const c = actColor(a.id);
  const live = isRun ? Math.floor(elapsed(r) / 60000) : 0;
  const dn = minutesToday(a.id) + live; const tg = todayTarget(a.id); const met = tg > 0 && dn >= tg;
  const nx = nextForAct(a.id);
  return `<div class="act click" style="${isRun ? `border-color:${c};background:${c}22` : ""}" data-a="actTap" data-id="${a.id}">
    <div class="line" style="display:flex;align-items:center"><span style="font-size:24px">${actIcon(a.id)}</span><span style="flex:1"></span>
      <button class="x" data-a="actEdit" data-id="${a.id}" title="Edit">✎</button>
      <span class="playbtn" style="background:${isRun ? c : c + "2e"};color:${isRun ? "var(--bg)" : c}">${isRun ? "■" : "▶"}</span></div>
    <div class="n">${h(a.name)}</div>${nx ? `<div class="small" style="color:${c}">→ ${h(nx)}</div>` : ""}
    <div class="${met ? "green" : "gold2"}" style="font:bold 22px var(--serif)">${fmtMin(dn)}</div>
    ${tg > 0 ? bar(dn / tg, met ? "var(--green)" : c) + `<div class="small ${met ? "green" : "muted"}">${met ? "✓ Done for today" : fmtMin(tg - dn) + " left today"}</div>` :
      `<div class="small muted">${a.goal > 0 ? "✓ Week goal met" : "No weekly goal"}</div>`}</div>`;
}

function weekPace() {
  const l = acts().filter((a) => a.goal > 0); if (!l.length) return "";
  const dl = daysLeftInWeek();
  return `<div class="kicker">🏁 Week goals · ${dl} days left</div><div class="card sec">${l.map((a) => {
    const wk = minutesWeek(a.id), left = Math.max(0, a.goal - wk), per = Math.ceil(left / dl);
    return `<div class="row" style="display:block"><div class="line" style="display:flex"><span style="flex:1">${actIcon(a.id)} ${h(a.name)}</span><b class="${left ? "gold2" : "green"}">${fmtMin(wk)} of ${fmtMin(a.goal)}</b></div>
      ${bar(wk / a.goal, left ? actColor(a.id) : "var(--green)")}<div class="small ${left ? "muted" : "green"}">${left ? fmtMin(left) + " left · about " + fmtMin(per) + " a day until Sunday" : "✓ Goal met. Anything more is a bonus."}</div>
      ${per > 600 ? '<div class="small amber">That is more than a working day. Keep it, or set a goal you can hold.</div>' : ""}</div>`;
  }).join("")}</div>`;
}

function weekChart() {
  const mon = monday(); const days = [0, 1, 2, 3, 4, 5, 6].map((i) => addDays(mon, i)); const mins = days.map((d) => minutes(null, d, d));
  const top = Math.max(60, ...mins); const td = today();
  return `<div class="kicker">📊 This week · ${fmtMin(mins.reduce((a, b) => a + b, 0))}</div><div class="card pad sec"><div class="wchart">${days.map((d, i) => `<div class="wc">
    <span class="small ${d === td ? "gold" : "muted"}">${mins[i] ? fmtMin(mins[i]) : ""}</span><i style="height:${Math.max(3, (110 * mins[i]) / top)}px;background:${mins[i] ? (d === td ? "var(--gold)" : "rgba(212,175,55,.45)") : "var(--track)"}"></i>
    <b class="${d === td ? "gold" : "muted"}">${dow1(d)}</b></div>`).join("")}</div></div>`;
}

function history() {
  const all = sessions().slice().sort((a, b) => (b.d || "").localeCompare(a.d || "") || (b.at || "").localeCompare(a.at || "") || (b.id || "").localeCompare(a.id || ""));
  const shown = all.slice(0, UI.histShown); const td = today();
  let s = `<div class="kicker">🕘 History · ${all.length} entries</div><div class="card">`; let last = "";
  for (const x of shown) {
    if (x.d !== last) { s += `<div class="row" style="padding:8px 14px 2px"><b class="gold small">${dayLabel(x.d)} · ${fmtMin(minutes(null, x.d, x.d))}</b></div>`; last = x.d; }
    const open = x.d === td;
    s += `<div class="row ${open ? "click" : ""}" ${open ? `data-a="sessEdit" data-id="${x.id}"` : ""}><span class="bigicon sm" style="background:${actColor(x.act)}33">${actIcon(x.act)}</span>
      <div class="grow"><div class="t">${h(actName(x.act))}</div><div class="meta">${[x.at ? x.at + "–" + endTime(x.at, x.min) : "", h(x.note || "")].filter(Boolean).join("  ·  ")}</div></div>
      <b class="gold2">${fmtMin(x.min)}</b><span class="muted small">${open ? "✎" : "🔒"}</span></div>`;
  }
  if (!all.length) s += '<div class="empty">No time logged yet.</div>';
  s += `</div>${all.length > shown.length ? '<button class="ghost" style="margin-top:8px" data-a="histMore">Show more</button>' : ""}
    <div class="lock" style="margin:8px 4px">Past days are locked, on both devices. Today's entries can be fixed until midnight.</div>
    ${all.some((x) => x.d < addDays(td, -90)) ? '<button class="ghost small" data-a="clearOldTime">Clear time older than 90 days</button>' : ""}`;
  return s;
}

MODAL.act = (m) => {
  const d = m.d; const isNew = !m.id; const c = listColorOf(d.color || 0);
  return dlg(isNew ? "New activity" : "Edit activity", `<div class="line" style="display:flex;gap:10px;align-items:center"><span class="bigicon" style="background:${c}33">${h(d.icon)}</span>
      <input type="text" data-m="name" value="${h(d.name)}" placeholder="Name (e.g. English, Coding, Gym)" style="flex:1;font:600 18px var(--serif)" autofocus></div>
    ${isNew ? "" : `<div class="stats3"><div><b>${fmtMin(minutesToday(m.id))}</b><span>Today</span></div><div><b>${fmtMin(minutesWeek(m.id))}</b><span>This week</span></div><div><b>${fmtMin(minutes(m.id, "2000-01-01", today()))}</b><span>All time</span></div></div>
      <div class="kicker" style="margin-top:12px">☑ Steps</div>${actStepsBox(m.id, false)}`}
    <div class="kicker" style="margin-top:12px">🏁 Weekly goal</div>
    <div class="line"><input type="number" min="0" step="30" data-m="goal" value="${+d.goal || 0}" style="width:100px"> min a week ${+d.goal > 0 ? `<span class="muted small">(${fmtMin(+d.goal)}, about ${fmtMin(Math.floor(+d.goal / 7))} a day)</span>` : ""}</div>
    <div>${[0, 120, 180, 300, 600, 1200].map((x) => pill(x ? fmtMin(x) : "No goal", +d.goal === x, `data-a="mset" data-f="goal" data-v="${x}" data-num="1"`)).join("")}</div>
    <div class="kicker">🎨 Colour</div>${colorPick(d.color || 0)}<div class="kicker">✨ Icon</div>${iconPick(ACT_ICONS, d.icon)}`,
    `${isNew ? "" : '<button class="ghost red" data-a="actDel">Delete</button>'}<span style="flex:1"></span><button class="ghost" data-a="closeModal">Cancel</button><button class="btn" data-a="actSave">Save</button>`);
};
MODAL.sess = (m) => {
  const d = m.d; const isNew = !m.id; const td = today();
  return dlg(isNew ? "Add time" : "Edit time", `<div class="kicker">🎯 Activity</div><div>${acts().map((a) => pill(actIcon(a.id) + " " + h(a.name), d.act === a.id, `data-a="mset" data-f="act" data-v="${a.id}"`, actColor(a.id))).join("")}</div>
    <div class="kicker" style="margin-top:12px">⏳ How long</div><div class="line"><input type="number" min="1" data-m="min" value="${+d.min || ""}" style="width:100px" autofocus> min ${+d.min > 0 ? `<span class="muted small">${fmtMin(+d.min)}</span>` : ""}</div>
    <div>${[15, 30, 45, 60, 90, 120, 180].map((x) => pill(fmtMin(x), +d.min === x, `data-a="mset" data-f="min" data-v="${x}" data-num="1"`)).join("")}</div>
    <div class="kicker" style="margin-top:12px">🗓 When</div><div>${isNew ? [td, addDays(td, -1)].map((x) => pill(dayLabel(x), d.d === x, `data-a="mset" data-f="d" data-v="${x}"`)).join("") : dayLabel(d.d)}</div>
    <div class="line"><label>Started at</label><input type="time" data-m="at" value="${h(d.at || "")}">${d.at && +d.min ? `<span class="muted small">to ${endTime(d.at, +d.min)}</span>` : ""}</div>
    <div class="kicker">📝 Notes</div><input type="text" data-m="note" value="${h(d.note || "")}" placeholder="What did you do? (optional)" style="width:100%">
    <div id="sess_why" class="red small"></div>`,
    `${isNew ? "" : '<button class="ghost red" data-a="sessDel">Delete</button>'}<span style="flex:1"></span><button class="ghost" data-a="closeModal">Cancel</button><button class="btn" data-a="sessSave">Save</button>`);
};

Object.assign(A, {
  mode(el) { setSetting("mode", el.dataset.v); commit(); },
  actTap(el) {
    const r = running();
    if (r && r.act === el.dataset.id) { A.stop(); return; }
    startTimer(el.dataset.id, +setting("mode", "0") || 0); notified = false; commit();
  },
  actNew() { openModal("act", { d: { name: "", goal: 0, icon: "⏱", color: 0 } }); },
  actEdit(el) { const a = act(el.dataset.id); if (a) openModal("act", { id: a.id, d: { name: a.name, goal: a.goal || 0, icon: actIcon(a.id), color: a.color || 0 } }); },
  actSave() {
    const m = UI.modal; const d = m.d; const name = (d.name || "").trim(); if (!name) { toast("Give the activity a name"); return; }
    saveAct(m.id, { name, goal: Math.max(0, parseInt(d.goal, 10) || 0), icon: d.icon, color: d.color }); UI.modal = null; commit();
  },
  async actDel() { if (!await ask("Delete this activity? All its time entries are deleted too. This cannot be undone.")) return; deleteAct(UI.modal.id); UI.modal = null; toast("Activity and its time deleted"); commit(); },
  sessNew() { openModal("sess", { d: { act: setting("lastAct") && act(setting("lastAct")) ? setting("lastAct") : (acts()[0] || {}).id, min: 30, d: today(), at: "", note: "" } }); },
  sessEdit(el) { const x = find("sessions", el.dataset.id); if (!x || x.d < today()) return; openModal("sess", { id: x.id, d: { act: x.act, min: x.min, d: x.d, at: x.at || "", note: x.note || "" } }); },
  sessSave() {
    const m = UI.modal; const d = m.d; const min = parseInt(d.min, 10) || 0; const w = $("#sess_why");
    if (!d.act) { if (w) w.textContent = "Pick the activity"; return; }
    if (!(min > 0)) { if (w) w.textContent = "Type how many minutes"; return; }
    if (!saveSession(m.id, { act: d.act, d: d.d || today(), min, note: (d.note || "").trim(), at: d.at || "" })) { toast("A past day is locked"); return; }
    setSetting("lastAct", d.act); UI.modal = null; toast("+" + fmtMin(min) + "  " + actName(d.act)); commit();
  },
  async sessDel() { const x = find("sessions", UI.modal.id); if (!x || x.d < today()) return; if (!await ask("Delete this entry?")) return; removeId("sessions", x.id); UI.modal = null; commit(); },
  histMore() { UI.histShown += 50; render(); },
  async clearOldTime() { if (!await ask("Time entries from more than 90 days ago are deleted. This week's goals do not change. This cannot be undone.")) return; const n = clearSessions(addDays(today(), -90)); toast(n ? n + " time entries removed" : "Nothing that old"); commit(); },
});
